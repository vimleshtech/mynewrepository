fn = input('enter file name : ')

path = r'C:\Users\vkumar15\Desktop\Project Source Code\\'+fn

#print(path)

f = open(path,'w')

for i in range(0,5):
     d = input('enter data  : ')

     f.write(d)
     f.write('\n')


f.close()



