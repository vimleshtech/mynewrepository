# no argument no return 
def wel():
     print('function ---- ')
     print('welcome to fun world.. ')


# no argument with return
def getNum():
     a =111
     return a



#argument with no return
def add(a,b):
     c =a+ b
     print(c)
     
#argument with return
def sub(a,b):
     c =a-b
     return c

'''
wel() # call or invoke to function
wel()

d = getNum()
c =d+100
print(c)



add(911,22)
add(944,22)
add(c,11)



o = sub(121,3)
print(o)
'''








