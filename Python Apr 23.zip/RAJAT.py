a=RAJAT
for i in range(0,6):
        for b in range(0,i+1):
             split.a=a+1
          print('RAJAT',end=' ')
        print(a)
  
  
