'''
i  = 0 , c = 0 1 2
i  = 1 , c = 0 1 2 
'''
for i in range(0,4):
     #print(i)
     for c in range(0,3):
          print(c,end=' ')
     print()
     

#

for i in range(0,4):
     #print(i)
     for c in range(0,i+1):
          print('*',end=' ')
     print()


for i in range(5,0,-1):
     #print(i)
     for c in range(0,i):
          print('*',end=' ')
     print()
    
#print in reverse
for i in range(5,0,-1):
     print(i)
     
