
//system
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


//user component 
import { AppComponent } from './app.component';
import {TestComponent} from './test.component'
import {EmpAdd} from './empadd/empadd.component'
import {EmpShow} from './empshow/empshow.component'

import {FooterComponent} from './footer/footer.component'
import {EventComponent} from './event/event.component'



@NgModule({
  declarations: [
         TestComponent ,AppComponent,EmpAdd,EmpShow,FooterComponent,EventComponent

  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
