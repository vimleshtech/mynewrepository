import {Component} from '@angular/core'

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent {

name:string
address:string
id:number

name1="ntin"
gender="male"
    

}
