import {Component} from '@angular/core'


@Component({
  selector: 'emp-add',
  templateUrl: './empadd.component.html',
  styleUrls: ['./empadd.component.css']
})
export class EmpAdd {}
