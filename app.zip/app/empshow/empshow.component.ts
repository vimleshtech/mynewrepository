import {Component} from '@angular/core'


@Component({
  selector: 'emp-show',
  templateUrl: './empshow.component.html',
  styleUrls: ['./empshow.component.css']
})
export class EmpShow {

    empname="test user";
}
