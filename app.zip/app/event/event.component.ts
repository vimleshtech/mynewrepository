import {Component} from '@angular/core'

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent {    

price:number;
quantity:number;
total:number;

  constructor(){

    this.price =0;
    this.quantity=0;
    this.total=0;
  }

takePrice(event)
{
    this.price = event.target.value;
}

takeQunatity(event)
{
this.quantity = event.target.value;
}


}
