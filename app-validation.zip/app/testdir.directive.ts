import { Directive, ElementRef, Renderer } from '@angular/core';

@Directive({
  selector: '[appTestdir]'
})
export class TestdirDirective {

  constructor(private abc: ElementRef, private xyz: Renderer) { }

}
