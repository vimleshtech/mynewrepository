import { TestdirDirective } from './testdir.directive';

describe('TestdirDirective', () => {
  it('should create an instance', () => {
    //const directive = new TestdirDirective();
    //expect(directive).toBeTruthy();
  });
});
