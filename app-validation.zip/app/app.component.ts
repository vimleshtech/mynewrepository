import { Component } from '@angular/core';

//form validation 
import { FormGroup,FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'Angular Form Validation Tutorial';
  angForm: FormGroup;

  constructor(private fb: FormBuilder) {
   this.createForm();
 }
 //Validators.minLength(3), Validators.maxLength(8)
 createForm() {
  this.angForm = this.fb.group({
     name: ['',Validators.required ],
     address: ['', Validators.required ]
  });
}
/*
ngOnIt(){
this.angForm=new FormGroup({

  name: new FormControl('',Validators.compose([Validators.required,
   Validators.minLength(3),
  Validators.pattern("[\\w\\-\\s\\/]+")])) ,
  address: new FormControl('',Validators.compose([Validators.required ])) 
});

}*/

}
