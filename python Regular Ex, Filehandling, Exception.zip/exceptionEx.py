#exception handing 

try:  

  n = input('enter number ')
  d = input('enter number ')
  o = n/d
  print(o)

except ZeroDivisionError as aa:
  print('maths...error ',aa)
  
except: #to handle the error 
  print('invalid input ')
  
print('end of program')

