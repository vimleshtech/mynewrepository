f = open('C:\Users\hadoop.HP-BEAUTY\Desktop\emp.txt','r')
log = open('C:\Users\hadoop.HP-BEAUTY\Desktop\log.txt','w')
total = 0

ri= 0

for r in f.readlines():
  #print(r)
  ri=ri+1
  col =  r.split(',')
  try:
    
    total = total+int(col[3])
    #print(col[3])
  except:
    #print('error : ',r)
    log.write('error at row # '+ str(ri )+ '  : '+r)
    
print('total = ',total)
log.close()

f.close()



  
  
  

