'''
  q. WAP to show count rows from file
  q. wap to show count of word from file
  q. wap to show count of particular from file
  q. wap to show data in below format:
    emp.txt
       id,name,gender,salary
        1,aaa,m,32222



        output:
          m = 10
          f = 3
          

'''
f = open('C:\Users\hadoop.HP-BEAUTY\Desktop\Email Id.txt','r')

print(f)

#print(f.read())
#print(f.readline())
#print(f.readlines())

for r in f.readlines():
  #r = r.replace('\n','')
  #print (r)

  col= r.split('@')
  print(col[0],'\t',col[1])
 

f.close()


##### write to file
fout = open('C:\Users\hadoop.HP-BEAUTY\Desktop\Email Id.txt','a')
fout.write('skjhsjsg jshgsshgf sghfshgfs gsfsgf s')
fout.write('skjhsjsg jshgsshgf sghfshgfs gsfsgf s')
fout.write('skjhsjsg jshgsshgf sghfshgfs gsfsgf s')
fout.write('skjhsjsg jshgsshgf sghfshgfs gsfsgf s')

fout.close()









