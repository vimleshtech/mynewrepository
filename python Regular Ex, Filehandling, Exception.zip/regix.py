import re
#import time
#import threading
#import os
#import socket

line = "abcd hshsjh jsgsj  1234 are good is te"
  
mo = re.match( r'(.*) are (.*?) is (.*)', line, re.M|re.I)

if mo:
   print "matchObj.group() : ", mo.group()
   print "matchObj.group(1) : ", mo.group(1)
   print "matchObj.group(2) : ", mo.group(2)
   print "matchObj.group(3) : ", mo.group(3)
else:
   print "No match!!"

'''
emailid =input('enter emailid ')

data = open(r'file locaiton','r')

for l in data.readlienes():
        col=l.split(',')
        objage = re.match( r'(.*)@gmail.com', col[0] , re.M|re.I)
        objname = re.match( r'(.*)@gmail.com', col[0] , re.M|re.I)
        objemaili = re.match( r'(.*)@gmail.com', col[0] , re.M|re.I)
        objcomments = re.match( r'(.*)@gmail.com', col[0] , re.M|re.I)
        
        if objid and obcname and :
            print 'you are autherized'
        else:
            print 'you are not authorized'
            
'''

    


