package testcases;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeTest;

public class testclass1 {
	
  @Test(dataProvider = "dp",groups={"g2","g1"})
  public void f(String n, String pwd) {
	  System.out.println(n+"\t"+pwd);
  }

  
  //Object : is inbuilt class, which allocate dynamic memory 
  
  @DataProvider
  public Object[][] dp() {
						  
					    return new Object[][] {
					    	
					    				new Object[] { "a@gmail.com", "a" },
					    				new Object[] { "b@yahoo.com", "b" },
					    				new Object[] { "c@gmail.com", "cff" },
					    									    				
					    };
  }
  @BeforeTest
  public void beforeTest() {
  }

}
