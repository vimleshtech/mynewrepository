package testcases;

import org.testng.annotations.Test;

import exceReader.excelEx;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.DataProvider;

public class testWithExcel {
  @Test(dataProvider = "dp")
  public void f( String n,String e,String p) {
	  
	  System.out.println(n+"\t"+e+"\t"+p);
	  
	  WebDriver driver = new FirefoxDriver();
	  driver.get("https://www.naukri.com/");
	  driver.findElement(By.id("id")).sendKeys(e);
	  
  }

  @DataProvider
  public Object[][] dp() throws IOException {
    
	  excelEx o = new excelEx();
	  
	  Object oo[][] = o.getData();
	  return oo;
  }
}
