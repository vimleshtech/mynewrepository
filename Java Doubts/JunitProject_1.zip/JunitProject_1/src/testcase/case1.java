package testcase;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/*
 * Asset : is inbuilt class which provides various function of test case validation 
 */

public class case1 {

	static WebDriver driver =  null; 
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		driver = new FirefoxDriver();
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test1() {
		
		driver.get("http://erp.techvisionit.com/");				
		driver.findElement(By.id("txtUserName")).sendKeys("chahat");
		driver.findElement(By.id("txtPassword")).sendKeys("chahat@765");
		driver.findElement(By.id("btnSubmit")).click();
	}

	//@Ignore
	@Test
	public void test2()
	{
		//driver.findElement(By.className("sup-menu c-p")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath(".//*[@id='aspnetForm']/div[3]/div/ul[2]/li[3]/img")).click();
		//driver.findElement(By.linkText("Enquiry ")).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);		
		driver.findElement(By.xpath(".//*[@id='aspnetForm']/div[3]/div/ul[2]/li[3]/div/p[2]/a")).click();
		
		
	}
	
	@Test
	public void test3()
	{
		driver.findElement(By.id("ctl00_cpbody_ddlsource")).sendKeys("Sulekha");
		
		
	}
	
	
}
