package testcase;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import junit.framework.Assert;

public class loginTest {

	static WebDriver driver =  null;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		driver = new FirefoxDriver();
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		
		
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		driver.get("http://erp.techvisionit.com/");
	}

	
	@SuppressWarnings("deprecation")
	@Test
	public void test1() {
		
		driver.findElement(By.id("txtUserName")).clear();		
		driver.findElement(By.id("txtUserName")).sendKeys("");
		
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtPassword")).sendKeys("");
		
		driver.findElement(By.id("btnSubmit")).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		String msg = driver.findElement(By.id("lblmsg")).getText();
		/*
		if(!msg.equals("User name or Password cannot be empty")){
			
			//System.out.println("test case fail");
			fail("test case fail")			;
			
		}
		else
		{
			System.out.println("test case pass");
		}
		*/
		//or
		Assert.assertEquals("User name or Password cannot be empty", msg);//expected,actual
		
		int n=10;
		
		Assert.assertEquals(1111, n);
		
		
	}

	
	@Ignore
	@Test
	public void testInvalidPwd() {

		driver.findElement(By.id("txtUserName")).sendKeys("chahat");
		driver.findElement(By.id("txtPassword")).sendKeys("chahat@765");
		driver.findElement(By.id("btnSubmit")).click();
	}

	
	@Ignore
	@Test
	public void testInalidUid() {

		driver.findElement(By.id("txtUserName")).sendKeys("chahat");
		driver.findElement(By.id("txtPassword")).sendKeys("chahat@765");
		driver.findElement(By.id("btnSubmit")).click();
		
	}

	@Ignore
	@Test
	public void testValidId() {
		
		driver.findElement(By.id("txtUserName")).sendKeys("chahat");
		driver.findElement(By.id("txtPassword")).sendKeys("chahat@765");
		driver.findElement(By.id("btnSubmit")).click();
		
	}

}
