package mainpkg;

import org.apache.log4j.Logger;

public class startup {


	final static Logger logger = Logger.getLogger(startup.class);
	
	public static void main(String[] args) {

		
		logger.info("main function is started....");
		
		int a,b,c;

		a =0;
		b =3;
		
		logger.info("data init....");
		
		try
		{		
				c = a/b;
				System.out.println(c);
				
				logger.info("result printed...");		
		
		}
		catch (Exception e) {
		
			logger.fatal("main function is started....");
			
		}
		logger.debug("first logic - completed..");
		
		
		a =444;
		b =555;
		
		c = a+b;
		
		logger.info("variable re-init....");
		
		if(c==100){
			
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
		
		
		logger.info("end of project");
		

	}

}
