package mainpkg;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ObjectEx {


	public static void main(String[] args) throws IOException {

		FileInputStream fs = new FileInputStream("C:\\Users\\hp\\workspace\\FrameworkEx\\src\\objects.properties");

		Properties prop = new Properties();
		prop.load(fs);
		
		
		String url = prop.getProperty("url");
		

		System.out.println(url);
	 

		System.out.println(prop.getProperty("sqlpwd"));
		
		
	}

}
