package tescases;

import java.io.IOException;
import java.util.Properties;

import excelpkg.excelReader;
import objects.objectReader;

public class testcase {

	
	public static void main(String[] ss) throws IOException
	{		
		String data[][] = excelReader.readExcel();
		Properties prop = objectReader.readObject();
		
		for(int i=0; i<data.length;i++)
		{
			if(data[i][0].equals("superuser"))
			{
				continue;
			}
			testPerform(data[i][0], data[i][1],prop.getProperty("uid"),prop.getProperty("pwd"));
		}
		
	}	
	
	public static void testPerform(String uid, String pwd,String ukey, String pkey)
	{		
		if(uid.equals("abc") && pwd.equals("bcd"))
		{
			 
			System.out.println("pass");
		}
		else
		{
			System.out.println("fail");
		}		
	}
	
	
	
}
