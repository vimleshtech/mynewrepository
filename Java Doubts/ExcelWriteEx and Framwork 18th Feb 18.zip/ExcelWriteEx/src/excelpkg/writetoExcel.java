package excelpkg;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;


public class writetoExcel {

	public static void main(String[] args) throws IOException {

		FileInputStream fs = new FileInputStream("C:\\Users\\hp\\Desktop\\users.xls");
		HSSFWorkbook book = new HSSFWorkbook(fs);
		HSSFSheet sheet = book.getSheet("Sheet1");
		
		
		
		
		int rc,cc;
		rc =sheet.getPhysicalNumberOfRows();
		cc = sheet.getRow(0).getPhysicalNumberOfCells();
		
		for(int i=1; i<rc; i++)
		{
			HSSFRow row = sheet.getRow(i);
			HSSFCell cell = row.getCell(0);
			String uid = cell.getStringCellValue();
			
			cell = row.getCell(1);
			String pwd = cell.getStringCellValue();
						
			row.createCell(2);
			cell	 =row.getCell(2);
			
			if(uid.equals("abc") && pwd.equals("bcd"))
			{
				System.out.println("pass");				
				cell.setCellValue("pass");		
				
			}
			else
			{
				System.out.println("fail");
				
				cell.setCellValue("fail");
			}
		
		}
		
		
		//FileOutputStream out =new FileOutputStream(outPut);
		FileOutputStream fo = new FileOutputStream("C:\\Users\\hp\\Desktop\\users.xls");				
        book.write(fo);
        
        fo.close();
        
        
        
        

	}

}
