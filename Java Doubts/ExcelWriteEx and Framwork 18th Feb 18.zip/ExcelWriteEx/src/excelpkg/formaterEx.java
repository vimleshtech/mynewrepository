package excelpkg;


import java.text.SimpleDateFormat;
import java.util.Date;

public class formaterEx {

	
	public static void main(String[] ss)
	{
		
		Date d = new Date();
		System.out.println(d);
		
		SimpleDateFormat sm = new SimpleDateFormat("yyyy/MM/dd");
		System.out.println(  sm.format(d));
		
		
		
	}

}
