package excelpkg;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;


public class excelReader {

	public static String[][] readExcel() throws IOException {

		String data[][] = null;
		
		FileInputStream fs = new FileInputStream("C:\\Users\\hp\\Desktop\\users.xls");
		HSSFWorkbook book = new HSSFWorkbook(fs);
		HSSFSheet sheet = book.getSheet("Sheet1");
		
		int rc,cc;
		rc =sheet.getPhysicalNumberOfRows();
		cc = sheet.getRow(0).getPhysicalNumberOfCells();
		
		data = new String[rc-1][cc];
		
		for(int i=1; i<rc; i++)
		{
			HSSFRow row = sheet.getRow(i);
			HSSFCell cell = row.getCell(0);
			
			String uid = cell.getStringCellValue();			
			data[i-1][0] =uid;			
					
			cell = row.getCell(1);
			String pwd = cell.getStringCellValue();
			data[i-1][1] =pwd;
			
		}
		
		return data;
        
        

	}

}
