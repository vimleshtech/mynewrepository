package arrayModule;

public class TwoD {

	public static void main(String[] args) {
	
		
		String emp[][] = new String[3][2]; //3 row and 2 col
	
		int nn[][] = {{1,2,3},{3,4,3},{3,4,3},{2,3,222}};
		
		emp[0][0] ="10";
		emp[0][1] ="nitin";
		
		emp[1][0] ="20";
		emp[1][1] ="jatin";
		
		emp[2][0] ="30";
		emp[2][1] ="divya";
				
		//System.out.println(emp[1][1]);
		for(int i=0; i<3;i++)
		{
			System.out.print(emp[i][0]+"\t");
			System.out.println(emp[i][1]);
			
			
		}
		
		

	}

}
