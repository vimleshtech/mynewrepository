package arrayModule;

public class singleDArray {

	public static void main(String[] args) {

		int n[] = new int[4];
		n[0] =23;
		n[1] =22;
		n[2] =22;
		n[3] =20;
		
		int a[] = {33,33,22,3};
		
		
		//access array data
		//System.out.println(n[1]);
		//System.out.println(n[0]);
		//System.out.println(n[2]);
		//System.out.println(n[3]);
		
		//print sum of all elements 
		int sum = 0;
		
		for(int i=0; i<4;i++)
		{
			System.out.println(n[i]);
			sum = sum+n[i];
		}
		
		System.out.println("output :"+sum);
		
		
		for(int i=0; i<4;i++)
		{
			System.out.println(a[i]);	
		}
		
		//print in reverse 
		for(int i=3; i>=0;i--)
		{
			System.out.println(n[i]);	
		}
		

		
	}

}
