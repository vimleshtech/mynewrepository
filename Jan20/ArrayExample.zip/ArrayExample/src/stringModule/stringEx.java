package stringModule;

/*
 * wap to show count of word
 * wap to show count of chars
 * wap to convert sentence in proper case 
 *   this is java
 *   out : This Is Java
 *   
 *   
 */
public class stringEx {

	public static void main(String[] args) {
	
		String name ="NItin sinha";
		System.out.println(name);
		
		String ns="";
		ns  = name.toUpperCase();
		System.out.println(ns);
			
		
		ns  = name.toLowerCase();
		System.out.println(ns);
		
		ns = name.replace("i", "xyz");
		System.out.println(ns);
		
		//nitin ....
		ns = name.substring(1, 3);
		System.out.println(ns);
				
		int l = name.length();
		System.out.println(l);
		
		int ps =name.indexOf("s");
		System.out.println(ps);
		
		char c = name.charAt(2);
		System.out.println(c);
		
		//split
		String s[] = name.split(" ");
		//System.out.println(s[1]);
		
		for(int i=0; i<s.length;i++)
		{
			System.out.println(s[i]);	
		}
		
		////conditional 
		if(name.equals("nitin sinha"))
		{
			System.out.println("data is match");
		}
		else
		{
			System.out.println("data is not match");
		}

		
		
		if(name.equalsIgnoreCase("nitin sinha"))
		{
			System.out.println("data is match");
		}
		else
		{
			System.out.println("data is not match");
		}

		
		if(name.contains("nitin"))
		{
			System.out.println("data is match");
		}
		else
		{
			System.out.println("data is not match");
		}


		if(name.startsWith("N"))
		{
			System.out.println("data is match");
		}
		else
		{
			System.out.println("data is not match");
		}


		if(name.endsWith("N"))
		{
			System.out.println("data is match");
		}
		else
		{
			System.out.println("data is not match");
		}
		
		
		
	}

}
