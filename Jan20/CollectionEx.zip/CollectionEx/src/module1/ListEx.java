package module1;

import java.util.ArrayList;
import java.util.List;

public class ListEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//List  : parent  , ArrayList : child 
		List l = new ArrayList();
		l.add(11);
		l.add("ss");
		
		
		
	}

}
