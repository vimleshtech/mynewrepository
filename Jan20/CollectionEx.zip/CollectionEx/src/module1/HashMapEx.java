package module1;

import java.util.HashMap;
import java.util.Scanner;

import javax.xml.bind.SchemaOutputResolver;

public class HashMapEx {

	public static void main(String[] args) {
		
		HashMap m = new HashMap();
		m.put("a", "alpha");
		m.put("b", "beta");
		m.put("c", "cat");
		m.put("d", "delhi");
		m.put("z", "zerbra");
		
		
		Scanner sc = new Scanner(System.in);
		String s;
		
		System.out.println("enter key to search : ");
		s = sc.next();
		
		System.out.println(m.get(s));
		

	}

}
