package module1;

import java.util.ArrayList;

public class ArrayListEx {

	public static void main(String[] args) {

		ArrayList al = new ArrayList();
		
		al.add(111);    //0
		al.add("Nitin");//1
		al.add(true);    //2
		al.add(2000.11);
		
		System.out.println(al.size());
		
		al.remove(1); 
		System.out.println(al.size());
		
		System.out.println(al.get(1));
		
		//al.add(1, 10000);
		
		for(int i=0; i<al.size();i++)
		{
			System.out.println(al.get(i));	
		}
		
		
		
		//// with fix type 
		ArrayList<Integer> a = new ArrayList();
		a.add(111);
		//a.add("dd");
		
		
		
	}

}
