package InterfaceEx;

public class test2 extends abcd {

	@Override
	void add(int a, int b) {
		// TODO Auto-generated method stub
		
	}

}
