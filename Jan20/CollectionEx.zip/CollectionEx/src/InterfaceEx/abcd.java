package InterfaceEx;

public abstract class abcd {

	abstract void add(int a, int b);
	
	void sub(int a, int b)
	{
		int c=a-b;
		System.out.println(c);
	}
}
