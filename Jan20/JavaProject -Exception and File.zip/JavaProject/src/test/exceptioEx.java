package test;

import java.util.Scanner;

public class exceptioEx {

	public static void main(String[] aa) {

		
		int n,d,o;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter  data  : ");
		n = sc.nextInt();
		d = sc.nextInt();
		
		try
		{
			if(d<1)
			{
				Exception ee = new Exception("divisor cannot be less than 1");
				throw ee;
			}
			try {
				o = n/d;
				System.out.println("output = "+o);
				
				int nn[] = {11,23,233};
				
			}
			catch (Exception e) {
				System.out.println(e);
			}
				
			/*
			for(int i=0; i<10; i++)
			{
				System.out.println(nn[i]);
			}
			*/
			
		}
		catch (ArithmeticException s) {
			System.out.println("invalid input , "+s);
			
		}
		catch (ArrayIndexOutOfBoundsException e) {
			// TODO: handle exception
			System.out.println(e);
		}
		catch(Exception e)
		{
			
		}
		finally {
			n=0;
			d =0;
			o=0;
			
		}
		System.out.println("end of code...");
		
		

		

	}

}
