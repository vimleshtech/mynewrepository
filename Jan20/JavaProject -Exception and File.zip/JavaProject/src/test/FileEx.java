package test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileEx {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		FileReader fr = new FileReader("C:\\Users\\vkumar15\\Desktop\\Azure Session - Apr 6.txt");
		BufferedReader br  = new BufferedReader(fr);
		
		String d ="";
		while((d= br.readLine()) !=null)
		{
			System.out.println(d);
		}
		
		br.close();
		fr.close();
		
	}

}
