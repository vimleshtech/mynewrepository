package test;

import java.util.Scanner;

public class startup {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter  data  : ");
		String s = sc.nextLine();
		
		String ss ="this is \" shskhsj";
				
		s = s.replace("\\n", "_");
		System.out.println(s);
		
		String aa[] = 	s.split("_");
		System.out.println(aa.length);
		
		
		
		s ="This is JaVa";
		int uc=0,lc=0;
		for(int i=0; i<s.length();i++)
		{
			int n = s.charAt(i);
			if(n>=65 && n<=91)
			{
				uc++;
			}
			else if(n>=96 && n<=123)
			{
				lc++;
			}
		}
		
		System.out.println(uc);
		System.out.println(lc);
	}

}

