package inheritEx;

public class b extends accounts {

}
