package inheritEx;

public class SavingAccounts extends accounts {

	String panno;
	String aadhno;
	final int minbal=10000;
	
	
	void newAccount(int acno, String aname, int bal,String pno, String aano)
	{
		if(bal<minbal)
		{
			System.out.println("min balance should be 10000 to open new account");
			System.exit(0);
		}
		super.newAccount(acno, aname, bal);
		panno = pno;
		aadhno = aano;
		
	}
	
	void disp()
	{
		super.disp();
		System.out.println("PAN # "+panno);		
		System.out.println("AADH # "+aadhno);
		
	}
	
}
