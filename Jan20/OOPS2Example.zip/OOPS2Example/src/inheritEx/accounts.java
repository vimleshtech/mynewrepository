package inheritEx;

public class accounts {

	int acno;
	String aname;
	int bal;
	
	void newAccount(int acno, String aname, int bal)
	{
		
		this.acno = acno;
		this.aname = aname;
		this.bal = bal;
	}
	
	void disp()
	{
		System.out.println("Ac # "+acno);
		System.out.println("Ac Name "+aname);
		System.out.println("Balance # "+bal);
		
	}
}
