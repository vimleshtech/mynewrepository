package inheritEx;

public class startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SavingAccounts o = new SavingAccounts();
		o.newAccount(111, "ABCD ", 22220,"ABCSDDD","ADH991");
		o.disp();
		
	}

}
