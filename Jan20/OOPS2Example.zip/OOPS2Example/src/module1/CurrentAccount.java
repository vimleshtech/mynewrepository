package module1;

public class CurrentAccount extends Account {

	String gstNo;
	
	public void newAccount()
	{
		super.newAccount();
		gstNo = "GST3333";
			
	}
	
	public void AccountDetails()
	{
		super.AccountDetails();
		System.out.println( gstNo);		
			
	}
}
