package module1;

public class Account {

	int accNo;
	String accName;
	int accBal;
	String panNo;
	
	void newAccount()
	{
		accNo =1111;
		accName = "ABC";
		accBal = 100000;
		panNo = "PAN3333";
			
	}
	
	 void AccountDetails()
	{
		System.out.println( accNo);
		System.out.println( accName);
		System.out.println( accBal);
		System.out.println( panNo);
		
			
	}
	
	
}
