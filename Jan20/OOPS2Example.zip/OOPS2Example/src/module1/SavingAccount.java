package module1;

public class SavingAccount  extends Account{

	String adhNo;
	
	public void newAccount()
	{
		super.newAccount();
		adhNo = "GST3333";
			
	}
	
	public void AccountDetails()
	{
		super.AccountDetails();
		System.out.println( adhNo);		
			
	}
	
}
