package PolyEx;

public class dcalc extends clac {

	void wel()
	{
		System.out.println("welcome to fun world dcalc..");
	}
	
	void add(int a, int b, int c)
	{
		int d = a+b+c;
		System.out.println(d);
	}
	
}
