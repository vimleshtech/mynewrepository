package PolyEx;

import javax.sound.midi.Soundbank;

public class clac {

	void wel()
	{
		System.out.println("welcome to fun world..");
	}
	
	void add(int a, int b)
	{
		int c=a+b;
		System.out.println(c);
	}
	
	void mul(int a, int b)
	{
		int c=a*b;
		System.out.println(c);
	}
	
}
