package PolyEx;

public class startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		clac c = new clac();
		c.wel();//parent 
		
		dcalc o = new dcalc();
		o.wel();
		o.add(11, 2);
		o.add(22, 33,3);

		//overriding 
		c = o;
		c.wel(); //child
		//or
		
		clac oo = new dcalc();
		oo.wel();
		
	}

}
