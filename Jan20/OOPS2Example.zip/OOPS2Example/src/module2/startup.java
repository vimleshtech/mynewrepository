package module2;

import java.util.Currency;
import java.util.Scanner;

import module1.CurrentAccount;
import module1.SavingAccount;

public class startup {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		//this is 
		char c[] = sc.nextLine().toCharArray();
		
		char c1 = sc.nextLine().charAt(0);
		
		
		
		SavingAccount so = new SavingAccount();
		CurrentAccount co = new CurrentAccount();
		
		so.newAccount();
		co.newAccount();
		co.AccountDetails();
		so.AccountDetails();
		

	}

}
