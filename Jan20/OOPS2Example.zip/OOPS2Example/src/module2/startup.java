package module2;

import java.util.Currency;

import module1.CurrentAccount;
import module1.SavingAccount;

public class startup {

	public static void main(String[] args) {

		
		SavingAccount so = new SavingAccount();
		CurrentAccount co = new CurrentAccount();
		
		so.newAccount();
		co.newAccount();
		co.AccountDetails();
		so.AccountDetails();
		

	}

}
