package consEx;

public class startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		emp e = new emp();
		e.disp();
		
		e.newEmp(11, "Jatin", 22333);

		e.disp();
		
		//with paramenter cons
		emp o = new emp("uk");
		o.disp();
		
		//copy cons
		emp ee = new emp(e);
		ee.disp();
		
	}

}
