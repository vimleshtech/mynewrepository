package consEx;

public class emp {

	int eid;
	String ename;
	int sal;
	
	//constructor : without parameter 
	emp()
	{
			ename ="Guest User";
			System.out.println("Object initialized");
			
	}
	//with parameter
	emp(String country) 
	{
		if(country.equals("india"))
			ename ="Guest User";
		else if(country.equals("us"))
			ename ="New User";
		else if(country.equals("uk"))
			ename ="User Name is not mention";
		
		
			System.out.println("Object initialized");
			
	}
	//copy constructor 
	emp(emp o)
	{
			this.ename=o.ename;
			ename ="Guest User";
			System.out.println("Object initialized");
			
	}
	
	void newEmp(int id, String name, int sal)
	{
		eid =id;
		this.ename = name;
		this.sal =sal;
	}
	
	void disp()
	{
		System.out.println("Employee Id = "+eid);
		System.out.println("Employee Name = "+ename);
		System.out.println("Employee Salary = "+sal);
	}
	
}
