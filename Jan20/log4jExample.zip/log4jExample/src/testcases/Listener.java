package testcases;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;

public class Listener {

	
}
