package startup;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class test1 {

	private final static Logger log = Logger.getLogger(test1.class);
	
	public static void main(String[] args) {

		log.info("*****************************");
		log.info("Main function invoked...");
		log.debug("before add function call...");
		add(11,30);
		log.debug("after add function call...");
		
		log.debug("before div function call...");		
		div(11,2);
		log.debug("after div function call...");
		
		log.debug("before sub function call...");
		sub(11,5);
		log.debug("after sub function call...");
		
		
		try
		{
		div(11,0);
		}
		catch (Exception e) {
			log.error("before add function call...");
		}
		log.info("program end");

	}

	public static void div(int a, int b)
	{
		int c;
		c = a/b;
		System.out.println("div of two :"+c);
		
	}
	
	public static void sub(int a, int b)
	{
		int c;
		c = a-b;
		System.out.println("sub of two :"+c);
		
	}
	
	public static void add(int a, int b)
	{
		int c;
		c = a+b;
		System.out.println("sum of two :"+c);
		
	}
}
