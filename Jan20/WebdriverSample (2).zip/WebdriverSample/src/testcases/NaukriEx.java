package testcases;

import java.io.File;
import java.io.IOException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;

public class NaukriEx {

	public static void main(String[] args) throws IOException {
		
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.naukri.com/");
		
		//File src = 	((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		//FileHandler.copy(src, new File("C:\\Users\\Tech Vision\\Desktop\\out.jpg"));
		
		
	Set<String> wins = 	driver.getWindowHandles();
	
	System.out.println(wins.size());
	
	for(String win: wins)
	{
		driver.switchTo().window(win);
		String title = driver.getTitle();
		System.out.println(title);
		
		if(title.contains("Jobs"))
		{
			driver.findElement(By.id("login_Layer")).click();
			
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.findElement(By.id("eLoginNew")).clear();
			driver.findElement(By.id("eLoginNew")).sendKeys("vimlesh073@gmail.com");
			
			
			
			
		}
	}
		
	
		
		
		
	
		
		

	}

}
