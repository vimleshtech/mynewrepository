package module1;

public class startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//create object 
		emp o = new emp(); //new is keyword to allcoate the memory 
		
		o.showEmp();
		
		//o.newEmp();  //invoke to function
		
		//o.showEmp();
		
		//create object with argument
		emp o1 = new emp("India");
		o1.newEmp();
		o1.showEmp();
		
		
		////
		emp oo = new emp(o);
		
		oo.showEmp();
		
		
		
		
	}

}
