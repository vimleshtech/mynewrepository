package module1;

import java.util.Scanner;

public class emp {

	
	///data member or member variable 
	int empid;
	String name;
	String addres;
	int hra;
	int basic;
	int s1,s2,s3;
	int t;
	
	//constructor : default  
	emp()
	{
			empid =0;
			name ="Guest";
			addres ="";
			hra = 0;
			basic = 0;		
			System.out.println("object initialized");
			
	}
	//with argument
	emp(String Country)
	{
		if(Country.equals("US"))
		{
			empid =0;
			name ="New User";
			addres ="";
			hra = 0;
			basic = 0;
			
			s1 =1000000;
			s2 =2000000;
			s3 =4000000;
		}
		else if(Country.equals("UK"))
		{
			empid =0;
			name ="NA";
			addres ="";
			hra = 0;
			basic = 0;
			
			s1 =1500000;
			s2 =3000000;
			s3 =5000000;
			
		}
		else
		{
			empid =0;
			name ="Guest User";
			addres ="";
			hra = 0;
			basic = 0;
			s1 =300000;
			s2 =500000;
			s3 =1000000;
		}
			System.out.println("object initialized -with argument");
			
	}
	
	//copy constructor 
	emp(emp o)
	{
			name=o.name;
			s1=o.s1;
			s2 = o.s2;
			s3 = o.s3;
			t = o.t;
	}
	
	//function 
	void newEmp()
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter empid : ");
		empid = sc.nextInt();
		
		System.out.println("enter name : ");
		name = sc.next();
		
		System.out.println("enter address : ");
		addres= sc.next();
		
		System.out.println("enter hra : ");
		hra= sc.nextInt();
		
		System.out.println("enter basic : ");
		basic = sc.nextInt();
		
	}
	
	void showEmp()
	{
		
		System.out.println("*** information****");
		System.out.println("empid : "+empid);
		System.out.println("Name: "+name);
		System.out.println("Address : "+addres);
		System.out.println("HRA : "+hra);
		System.out.println("Basic : "+basic);
		
		int total =( hra+basic)*12;
		double tax = 0;
		
		if(total<s1)
		{
			tax = 0;
		}
		else if(total<s2)
		{
			tax = (total-s1)*.05;
			
		}
		else if(total<s3)
		{
			tax = (total-s1)*.20;
			
		}
		else
		{
			tax = (total-s1)*.30;
		}
		t = tax;
		
		System.out.println("Tax : "+tax);
	}	
	
}
