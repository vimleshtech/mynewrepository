package testcases;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class NewTest {
  @Test(priority=3,dependsOnMethods={"t"},groups={"a"})
  public void f() {
	  System.out.println("f");

	  //Assert.assertEquals(actual, "google")
			  
  }
  @Test(priority=2,enabled=true,groups={"b","a"})
  public void a() {
	  System.out.println("a");
  }
  @Test(priority=1,groups={"a","b"})
  public void t() {
	  
	  System.out.println("t");
	  
	  int n=22;
	  int d =0;
	  
	  int o = n/d;
	  
	  
  }
  
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterMethod
  public void afterMethod() {
  }

  @BeforeClass
  public void beforeClass() {
  }

  @AfterClass
  public void afterClass() {
  }

  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

  @BeforeSuite
  public void beforeSuite() {
  }

  @AfterSuite
  public void afterSuite() {
  }

}
