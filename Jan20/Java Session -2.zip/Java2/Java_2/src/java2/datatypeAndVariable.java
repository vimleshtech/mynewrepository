package java2;

public class datatypeAndVariable 
{

	//global variable 
	static int b;  //static variable 
	int c;  //instance variable
	
	public static void main(String[] args) 
	{		
		//access instance variable 
		datatypeAndVariable o1 = new datatypeAndVariable();
		o1.c =1;
		
		//access static variable
		b =11;
		
		
		//local variable 
		int a;
		a =10;
		
		

	}
	
	public static void test()
	{
		//access global - static variable
		b =333;
	}

}
