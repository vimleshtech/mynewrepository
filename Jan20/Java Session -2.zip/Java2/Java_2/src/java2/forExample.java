package java2;

public class forExample {

	public static void main(String[] args) {
	
		
		for(int i=1; i<10; i++)
		{
			System.out.println(i);
		}

		//print in reverse order
		for(int i=10; i>0; i--)
		{
			System.out.println(i);
		}
		//print all odd numbers between 1 to 87
		for(int i=1; i<=87; i=i+2)
		{
			System.out.println(i);
		}
		
		///print table 3 
		for(int i=1; i<=10; i++)
		{
			System.out.println("3 * "+i+"="+ i*3 );
			
		}
		
		
	}

}
