package java2;

public class dataTypeEx {
	public static void main(String[] args) {

		byte b =-100;
		short s = 100;
		int n =-112222;
		long l =222;
		
		
		float f =333.3f;
		double d =222.2222;
		
		char c='1';
		
		boolean bb = true;
		
		
		String name="lksj ssjh skjhskjs sjghs jshgsjhsg1`1233";
		
		System.out.print(b); // print -> but not change line
		System.out.println(s); //println -> print then change line
		
		//System.out.println(n);
		//System.out.println(l);
		//System.out.println(name);
		//System.out.println(bb);
		//System.out.println(f);
		
		
		

	}

}
