package java2;

public class switchEx {

	public static void main(String[] args) {

		int day;
		day =6;
		
		switch (day) {
			case 1:
				System.out.println("mon");
				break;
			case 2:
				
				System.out.println("tue");
				break;
			case 3:
				System.out.println("wed");
				break;

			default:
				System.out.println("invalid input");
				break;
		}
		
		

	}

}
