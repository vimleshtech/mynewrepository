package java2;

public class IfExample {

	public static void main(String[] args) {

		int n1,n2,n3;
		n1 =101;
		n2 =4499;
		n3 = 990;
		
		//if condition 
		//print if even 
		if(n1%2 ==0)
		{
			System.out.println("even no");
			
		}
		
		//if else 
		if(n1%2 ==0)
		{
			System.out.println("even no");
			
		}
		else
		{
			System.out.println(n1+" is odd no");
		}
		
		//if else if 
		if(n1>n2 && n1>n3)
		{
			System.out.println("n1 is greater no");
		}
		else if(n2>n1 && n2>n3)
		{
			System.out.println("n2 is greater no");
		}
		else
		{
			System.out.println("n3 is greater no");
		}
		
		//nested if : if inside if 
		if(n1>n2)
		{
			if(n1>n3)
				System.out.println("n1 is greater no");
			else
				System.out.println("n3 is greater no");
		}
		else 
		{
			if(n2>n3)
				System.out.println("n2 is greater no");
			else
				System.out.println("n3 is greater no");
		}
		
		
	}

}
