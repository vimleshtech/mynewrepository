package objects;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class objectManager {


	public  static Properties getObjects() throws IOException
	{
		FileInputStream fs = new FileInputStream("C:\\Users\\hp\\workspace\\TestNGPro\\src\\objects\\objects.properties");
		Properties prop = new Properties();
		prop.load(fs);
		return prop;
	}

}
