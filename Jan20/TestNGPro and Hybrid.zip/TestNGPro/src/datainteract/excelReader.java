package datainteract;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class excelReader {

	public static String[][] getTestcase() throws IOException	
	{
		String data[][]=null;
		
		FileInputStream fs = new FileInputStream("C:\\Users\\hp\\Desktop\\testcase.xls");
		HSSFWorkbook book = new HSSFWorkbook(fs);
		HSSFSheet sheet = book.getSheet("testcase");
		
		int rc,cc;
		rc=sheet.getPhysicalNumberOfRows();
		cc=sheet.getRow(0).getPhysicalNumberOfCells();
		
		data=new String[rc-1][cc-1];
		
		for(int i=1; i<rc;i++)
		{
			HSSFRow row = sheet.getRow(i);
			//for(int c=0; c<cc;c++)
			//{
				HSSFCell cell = row.getCell(0);
				data[i-1][0] = cell.getStringCellValue();
				
				cell = row.getCell(2);
				data[i-1][1] = cell.getStringCellValue();
				
				cell = row.getCell(3);
				data[i-1][2] = cell.getStringCellValue();
				
				cell = row.getCell(4);
				data[i-1][3] = cell.getStringCellValue();
				
				
				
			//}
		}
		
		
		return data;
		
	}
}
