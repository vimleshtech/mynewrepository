package testcases;

import org.testng.annotations.Test;

import javax.sound.midi.Soundbank;

import org.testng.annotations.DataProvider;

public class NewTest1 {
  @Test(dataProvider = "dp")
  public void f(Integer n, String s,String p) {
	  System.out.println(n+"\t"+s+"\t"+p);
	  
	  
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { 1, "a@gmail.com","ffff" },
      new Object[] { 2, "dsjhj@gmasil.com","djkshs" },
      new Object[] { 3, "dsjhj@gmasil.com","djkshs" },
      
    };
  }
}
