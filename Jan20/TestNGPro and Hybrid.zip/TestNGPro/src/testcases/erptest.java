package testcases;

import org.testng.annotations.Test;

import datainteract.excelReader;
import objects.objectManager;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

public class erptest {

	Properties prop = null;
	WebDriver driver = null;
	@BeforeTest
	public void beforetest()
	{
		try{
				
		
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
	}
  @Test(dataProvider = "dp")
  public void f(String tid, String st,String data,String eo) throws IOException {
		
	  prop=objectManager.getObjects();
	  driver=new FirefoxDriver();
	  driver.get(prop.getProperty("url"));
		
	  String d[] = data.split(",");
	  
	  String uid,pwd;
	  uid = d[0].replace("UID=", "");
	  pwd= d[1].replace("PWD=", "");
	  
	  driver.findElement(By.id(prop.getProperty("login.uid"))).sendKeys(uid);
	  driver.findElement(By.id(prop.getProperty("login.pwd"))).sendKeys(pwd);
	  driver.findElement(By.id(prop.getProperty("login.signin"))).click();
	  
	  
  }

  @DataProvider
  public Object[][] dp() throws IOException {
	  	
	  Object o[][] = excelReader.getTestcase();	  
	  return o;
  }
}
