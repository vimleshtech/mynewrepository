package testcases;

import org.testng.annotations.Test;

import excelUtils.objectReader;
import utils.WebElementHandler;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class logingTest {
	
	WebDriver driver = null;
	Properties prop = null;
	WebElementHandler web = null;
	WebElement element = null;
	
  @Test(testName="invalid uid and pwd",priority=0)
  public void login1() {
	  
	  element =   web.findElement("id", prop.getProperty("uwe"), driver);
	  web.webAction(element, "sendkeys", "data");
	  
	  
	  element =   web.findElement("id", prop.getProperty("pwe"), driver);
	  web.webAction(element, "sendkeys", "data");
	  
	  
	  element =   web.findElement("id", prop.getProperty("lwe"), driver);
	  web.webAction(element, "click", "");
	  
	  
	  
	  
  }

  @Test(testName="valid uid and pwd",priority=1)
  public void login2() {
	  
	  element =   web.findElement("id", prop.getProperty("uwe"), driver);
	  web.webAction(element, "sendkeys", "chahat");
	  
	  
	  element =   web.findElement("id", prop.getProperty("pwe"), driver);
	  web.webAction(element, "sendkeys", "abcd");
	  
	  
	  element =   web.findElement("id", prop.getProperty("lwe"), driver);
	  web.webAction(element, "click", "");
  }
  
  
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterMethod
  public void afterMethod() {
  }

  @BeforeClass
  public void beforeClass() {
  }

  @AfterClass
  public void afterClass() {
  }

  @BeforeTest
  public void beforeTest() throws IOException {
	  driver = new FirefoxDriver();
	  driver.get(prop.getProperty("url"));
	  prop = objectReader.readObject();
	  web = new WebElementHandler ();
	  
  }

  @AfterTest
  public void afterTest() {
  }

  @BeforeSuite
  public void beforeSuite() {
  }

  @AfterSuite
  public void afterSuite() {
  }

}
