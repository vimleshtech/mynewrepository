package excelUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class objectReader {

	public static  Properties readObject() throws IOException
	{
		FileInputStream fs = new FileInputStream("C:\\Users\\hp\\workspace\\HybridProject\\src\\objects\\objects.properties");
		Properties prop = new Properties();
		prop.load(fs);

		return prop;
	}
}
