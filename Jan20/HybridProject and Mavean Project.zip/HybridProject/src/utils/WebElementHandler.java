package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.WebDriverEventListener;

public class WebElementHandler {

	
	public WebElement findElement(String key, String value,WebDriver d)
	{
		key = key.toUpperCase();
		WebElement el = null;
		switch (key) {
		case "ID":
			el = d.findElement(By.id(value));
			
			break;
		case "NAME":
			el = d.findElement(By.name(value));
			break;
		case "XPATH":
			el = d.findElement(By.xpath(value));
			
			break;
		case "CLASSNAME":
			el = d.findElement(By.className(value));
			break;
		case "LINKTEXT":
			el = d.findElement(By.linkText(value));
			break;
		case "TAGNAME":
			el = d.findElement(By.tagName(value));
			break;
		default:
			break;
		}
		return el;
	}
	
	public String webAction(WebElement el, String key, String value)
	{
		String msg = "";
		
		key= key.toUpperCase();
		switch (key) {
		case "CLICK":
			el.click();
			break;
		case "SENDKEYS":
			el.clear();
			el.sendKeys(value);
			break;
		case "GETTEXT":
			msg = el.getText();
			break;
		case "CLEAR":
			el.clear();
			break;
		default:
			break;
		}
		return msg;
		
		
		
	}
}
