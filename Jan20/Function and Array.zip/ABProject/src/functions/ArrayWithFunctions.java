package functions;

import javax.xml.bind.SchemaOutputResolver;

public class ArrayWithFunctions {

	public static void main(String[] args) {
		
		String s ="rskjshgjsgsjaj sinha";
		//String ns = s.substring(0, 6);
		String n[] = s.split(" ");
		//[raj,sinha]
		
		System.out.println(n[0]);
		
		////
		int num[] ={11,22,3222,221,112};
		//System.out.println(num[0]);
		//System.out.println(num[1]);
		
		
		//for(int d : num)
		for(int i=0; i<num.length;i++)
		{
			System.out.println(num[i]);
		}
		
		
		

		
		
		
		

	}

}
