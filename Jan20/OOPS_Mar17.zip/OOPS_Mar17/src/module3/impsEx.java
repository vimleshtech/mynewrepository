package module3;

public class impsEx implements Ia {

	//read only variable 
	
	final int d=100;
	final String cname="Tech Vision";
	
	static void test()
	{
		System.out.println("test");
	}
	@Override
	public void add(int a, int b) {
		// TODO Auto-generated method stub
		
		
		
		int c = a+b;
		System.out.println(c);
	}

	@Override
	public void add(int a, int b, int c) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void add(int a, double b) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int sub(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

}
