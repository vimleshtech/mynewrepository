package module3;

public class start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Ia o = new impsEx();
		o.add(11, 22);

		//can be access without object
		impsEx.test();
		
		//impsEx.add(111,22) ; //cannot be accessed
		
	}

}
