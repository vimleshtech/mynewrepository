package module3;

public interface Ia {

	void add(int a, int b);
	void add(int a, int b,int c);
	void add(int a, double  b);
	int sub(int a, int b);
	
}
