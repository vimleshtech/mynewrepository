package module1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class inputEx {

	public static void main(String[] args) throws IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("enter data :");
		int d1 = Integer.parseInt( br.readLine());
		
		System.out.println("enter data :");
		int d2 = Integer.parseInt( br.readLine());
		
		int d = d1+d2;
		
		
		System.out.println("You have entered :"+d);
		//or 
		Scanner sc = new Scanner(System.in);
		System.out.println("enter data :");
		int n1 = sc.nextInt();
		
		System.out.println("enter data :");
		int n2 = sc.nextInt();
		
		int n =n1+n2;
		System.out.println("You have entered :"+n);
		
		
		///
		int dd[] = new int[3];
		for(int i=0; i<3;i++)
		{
			System.out.println("enter data :");
			dd[i]= sc.nextInt();
				
		}
		
		///
		System.out.println("enter data :");
		char cc[] = sc.next().toCharArray();
		

		System.out.println("enter data :");
		String cc1 = sc.next();
		
		
	}

}
