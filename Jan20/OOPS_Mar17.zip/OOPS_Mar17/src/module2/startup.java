package module2;

public class startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		calc o = new extendedclass();
		o.add(11, 22);
		
		
	}

}
