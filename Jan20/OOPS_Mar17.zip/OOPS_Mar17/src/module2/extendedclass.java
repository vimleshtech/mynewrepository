package module2;

public class extendedclass extends calc {

	@Override //annotation 
	void add(int a, int b) {
		// TODO Auto-generated method stub
		
		int c = a+b;
		System.out.println(c);
		
	}

}
