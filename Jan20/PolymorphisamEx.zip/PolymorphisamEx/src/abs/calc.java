package abs;

import javax.sound.midi.Soundbank;

public abstract class calc {

	abstract void add(int a, int b);
	void sub(int a, int b)
	{
		int c = a-b;
		System.out.println(c);
		
	}
	
}
