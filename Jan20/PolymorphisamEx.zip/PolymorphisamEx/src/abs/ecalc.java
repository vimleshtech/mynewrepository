package abs;
public class ecalc extends calc {

	@Override
	void add(int a, int b) {
		int c = a-b;
		System.out.println(c);
		
	}

}
