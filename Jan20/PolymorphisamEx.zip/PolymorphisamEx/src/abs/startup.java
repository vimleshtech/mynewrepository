package abs;

public class startup {

	public static void main(String[] args) {

		calc c = new ecalc();
		c.add(11, 22);
		c.sub(22, 3);
		
		

	}

}
