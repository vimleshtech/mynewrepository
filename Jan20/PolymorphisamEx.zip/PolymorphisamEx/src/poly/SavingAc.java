package poly;

public class SavingAc {

	String aname,pan;
	int acno,amt;

	void add(int a, int b)
	{
		
		int c = a+ b;
		System.out.println("sum of int : "+c);
	}
	
	void welcome()
	{
		System.out.println("******-Min balanance/opening balance should be INR 10000-****");
	}
	void newAccount(int acno, String aname,int amt, String pan)
	{
		this.acno = acno;
		this.aname= aname;
		this.pan = pan;
		this.amt = amt;		
	}


	void showDetails()
	{
		System.out.println("*******************");
		System.out.println(this.acno);
		System.out.println(this.aname);
		System.out.println(this.pan);
		System.out.println(this.amt);
		
	}
}
