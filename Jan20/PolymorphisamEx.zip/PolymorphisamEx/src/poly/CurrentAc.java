package poly;

public class CurrentAc extends SavingAc {

	String gstn;
		

	void add(double a, double b)
	{
		double c = a+ b;
		System.out.println("sum of double : "+c);
	}
	
	//overridig 
	void welcome()
	{
		System.out.println("******-Min opening balance should be INR 50000 to open current account****");
	}
	
	//overloading
	void newAccount(int acno, String aname,int amt, String pan, String gstn)
	{
		super.newAccount(acno, aname, amt, pan);
		this.gstn = gstn;		
	}

	//overriding 
	void showDetails()
	{
		super.showDetails();
		System.out.println(this.gstn);
		
	}
}
