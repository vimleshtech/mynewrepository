package poly;

public class startup {

	public static void main(String[] args) {

		/*
		SavingAc sa = new SavingAc();
		//sa.newAccount(1001, "abcd", 13000, "bgrpk111");
		
		CurrentAc ca = new CurrentAc();		
		//ca.newAccount(1001, "abcd", 13000, "bgrpk111","1111");
		ca.newAccount(1001, "abcd", 13000, "bgrpk111"); //parent 
		
	
		//sa.showDetails();
		ca.showDetails(); //child 
		
		ca.welcome();
		sa.welcome();
		
		//overridign 
		sa  = ca;
		sa.welcome();
		
		
		//or
		SavingAc aa = new CurrentAc();
		aa.welcome();
		
		*/
		
		
		
		/*
		ca.add(11, 22); //parent 
 		ca.add(11, 22.32); //child
		ca.add(11.22, 22.33); //child 
		*/
		
		caller(new SavingAc());
		caller(new CurrentAc());
		
	}

	static void caller(SavingAc a)
	{
		//a.newAccount(acno, aname, amt, pan);
		a.welcome();
		a.showDetails();
		
	}
}
