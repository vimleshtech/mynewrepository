package interf;

public class calc implements Ia {

	@Override
	public void add(int a, int b) {
	
		int c= a+b;
		System.out.println(c);
		
		
	}

	@Override
	public int sub(int a, int b) {
		// TODO Auto-generated method stub

		int c= a-b;
		
		return c;
	}

}
