package coll;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sound.midi.Soundbank;

class emp
{
	int id;
	String name;
	emp(int id, String name)
	{
		this.id =id;
		this.name = name;
	}
	
}
public class startup {

	public static void main(String[] args) {

		
		ArrayList al =new ArrayList();
		al.add(11);
		al.add(21);
		al.add(11);
		al.add("dfdr");
		al.add(11);
		
		System.out.println(al.size());
		System.out.println(al.get(1));
		al.remove(1);
		System.out.println(al.size());
		System.out.println(al.get(1));
		
		
		for(int i=0; i<al.size();i++)
		{
			System.out.println(al.get(i));
		}

		///
		List l = new ArrayList();
		
		
		///
		ArrayList<Integer> a = new ArrayList<>();
		a.add(11);
		//a.add("dhd");
		
		
		////
		ArrayList<emp> e = new ArrayList<>();
		
		e.add(new emp(1,"sss"));
		e.add(new emp(2,"sss"));
		e.add(new emp(3,"sss"));
		e.add(new emp(4,"sss"));
		e.add(new emp(5,"sss"));
		
		
		//emp o = new emp(1,"dd");
		//e.add(o);
		
		for(int i=0; i<e.size(); i++){
			emp ee = (emp) e.get(i);
					
			System.out.println(ee.id+"\t"+ee.name);
		}
		
		
		
		////
		HashMap m = new HashMap();
		m.put("a", "alpha");
		m.put("b", "beta");
		
		System.out.println(m.get("b"));
		
		HashMap<Integer,emp> m1 = new HashMap();
		
		m1.put(100, new emp(100,"dhsjgsj"));
		
	}

}
