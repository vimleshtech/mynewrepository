package sales;

public class sales extends product {

	int pid; 
	
	public void newOrder(int qty)
	{
		int pid; //local 
		
		super.setProduct();
		
		int total = price*qty;
		System.out.println("product id  = "+super.pid);
		
		System.out.println("product id  = "+this.pid); //class - global member
		
		System.out.println("product name  = "+pname);
		System.out.println("total price = "+total);
		
	}
}
