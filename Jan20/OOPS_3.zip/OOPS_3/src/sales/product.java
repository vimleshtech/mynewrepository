package sales;

public class product {

	int pid;
	String pname;
	int price;
	
	public void setProduct()
	{
		pid =100;
		pname="Lakme";
		price = 700;
		
		
	}
}
