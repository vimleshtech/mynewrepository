package inheritence;

public class extendedCalc extends calc {
	
	
	public void calcTax(int amt)
	{
		float tax = amt * 0.18f;
		System.out.println("tax aout is : "+tax);
	}

}
