package inheritence;

public class calc {

	int c;
	
	public void add(int a, int b)
	{
		c = a+b;
		System.out.println("sum of two num : "+c);
	}
	public void sub(int a, int b)
	{
		c = a-b;
		System.out.println("sub of two num : "+c);
	}
	public void mul(int a, int b)
	{
		c = a*b;
		System.out.println("mul of two num : "+c);
	}
	public void div(int a, int b)
	{
		c = a/b;
		System.out.println("div of two num : "+c);
	}
		
	
}
