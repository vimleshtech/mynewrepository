package inheritence;

//multi level 
public class digitalCalc extends extendedCalc {

	public void test()
	{
		System.out.println("class digital calc and function test");
	}
}
