package inheritence;

import sales.*;

public class startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		calc o =new calc();
		o.add(110, 22); //call to function / invoke to functioin
		o.sub(11, 2);
		o.div(12, 2);
		o.mul(110, 22);
		*/
		/*
		extendedCalc c = new extendedCalc ();
		c.calcTax(112233);
		c.add(110, 22); //call to function / invoke to functioin
		c.sub(11, 2);
		c.div(12, 2);
		c.mul(110, 22);
		*/
		
		digitalCalc c = new digitalCalc ();
		c.calcTax(112233);
		c.add(110, 22); //call to function / invoke to functioin
		c.sub(11, 2);
		c.div(12, 2);
		c.mul(110, 22);
		c.test();
		
		sales s = new sales();
		//s.setProduct();
		s.newOrder(20);
		
		
		
	}

}
