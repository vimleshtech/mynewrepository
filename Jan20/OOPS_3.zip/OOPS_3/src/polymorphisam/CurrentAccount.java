package polymorphisam;

public class CurrentAccount extends Account {

	String gstn;
	
	public void welcome()
	{
		System.out.println("current accout");
	}
	public void setDefault()
	{
		ano = 0;
		aname =null;
		atype="Current Account";		
	}
	
	//overloading 
	public void newAccount(int ano, String aname, String pno,int amt,String gstn)
	{
		super.newAccount(ano, aname, pno, amt);
		this.gstn =gstn;
		
	}
	
	
}
