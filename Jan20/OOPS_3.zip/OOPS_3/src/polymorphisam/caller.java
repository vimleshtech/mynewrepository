package polymorphisam;

public class caller {

	public static void main(String[] a)
	{
		Account o = new Account();
		o.welcome(); //saving account
		o.newAccount(111, "nitin", "bgre23333", 100000);
		o.showDetails();
		
		
		CurrentAccount co = new CurrentAccount();
		co.welcome();//current account 
		//overloading 
		co.newAccount(111, "nitin", "bgre23333", 100000);
		co.newAccount(111, "nitin", "bgre23333", 100000,"gstn");
				
		
		//overriding
		Account ac = new CurrentAccount();
		ac.welcome(); // current account
		
		//or
		o = co;
		o.welcome(); //current account
		
		
		
		
	}
}
