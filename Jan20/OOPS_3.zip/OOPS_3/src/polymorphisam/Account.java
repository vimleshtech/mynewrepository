package polymorphisam;

public class Account {

	int ano;
	String aname;
	String atype;
	String pno;
	int bal;

	public void welcome()
	{
		System.out.println("saving accout");
	}
	public void setDefault()
	{
		ano = 0;
		aname =null;
		atype="Saving Account";		
	}
	
	public void newAccount(int ano, String aname, String pno,int amt)
	{
		this.ano = ano;
		this.aname = aname;
		this.pno = pno;
		bal = amt;
		
	}
	
	
	public void showDetails()
	{
		System.out.println("Acno : "+ano);
		System.out.println("A Name : "+aname);
		System.out.println("A Type : "+atype);
		
	}
	
}
