package testcases;

import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class loginwithExcel {

	public static void main(String[] args) {
	
		
		try
		{		
			//read excel(object) from physical path 
			FileInputStream fs = new FileInputStream("C:\\Users\\Tech Vision\\Desktop\\testcase.xls");
			
			//convert byte to excel 
			HSSFWorkbook book = new HSSFWorkbook(fs);
			HSSFSheet sheet = book.getSheet("Sheet1");
			
			int sc,rc,cc;
			sc = book.getNumberOfSheets();
			rc = sheet.getPhysicalNumberOfRows();
			cc = sheet.getRow(0).getPhysicalNumberOfCells();
						
			System.out.println("Sheet Count = "+sc);
			System.out.println("Row Count = "+rc);
			System.out.println("Col Count = "+cc);
			
			String tid="",email="",pwd="";
			
			for(int i=0; i<rc;i++)
			{
				HSSFRow row  = sheet.getRow(i);
				
				HSSFCell cell = row.getCell(0);
				tid = cell.getStringCellValue();
				
				cell = row.getCell(1);
				email = cell.getStringCellValue();
				
				cell = row.getCell(2);
				pwd= cell.getStringCellValue();
				
				
				System.out.println(tid+"\t"+email+"\t"+pwd);
				
			}
			
			WebDriver driver = new FirefoxDriver();
			driver.get("http://erp.techvisionit.com/");
			
			WebElement login=	driver.findElement(By.id("txtUserName"));
			login.clear();
			login.sendKeys(email);
			
			WebElement pd=	driver.findElement(By.id("txtPassword"));
			pd.clear();
			pd.sendKeys(pwd);
			
			
			WebElement btn=	driver.findElement(By.id("btnSubmit"));
		 	btn.click();
			
					
			
			
			
			
			
			
		}
		catch (Exception e) {
		
		}
		
		

	}

}
