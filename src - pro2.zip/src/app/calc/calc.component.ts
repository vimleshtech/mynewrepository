import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calc',
  templateUrl: './calc.component.html',
  styleUrls: ['./calc.component.css']
})
export class CalcComponent implements OnInit {

  total:number
  n1:number
  n2:number

  constructor() { 
    this.total = 100
    this.n1 = 0
    this.n2 =  0


  }

takeNum1(event){

  this.n1 = event.target.value;
  //alert("jhi");


}

takeNum2(event){  
this.n2 = event.target.value;

}
  ngOnInit() {
  }

}
