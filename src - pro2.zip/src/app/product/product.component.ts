import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

qt:number
pr:number
pwt:number

bs:number
hra:number
otax:number
m:number
y:number
inc:number
  constructor() {

this.qt = 0;
this.pr = 0;
this.pwt=0;
this.bs = 0;
this.hra = 0;
this.otax=0;
this.m=0;
this.y=0;
   }

  ngOnInit() {
  }


/*takeQt(event)
{
 this.qt = parseInt( event.target.value);

}

takePr(event)
{
  this.pr = parseInt( event.target.value);
  this.pwt =  this.qt   +  this.pr  

}

getPrice()
{
  this.pwt = (this.qt  +  this.pr) *1.18



}
*/

basic(event)
{
  this.bs = parseInt( event.target.value);

}


HRA(event)
{
  this.hra = parseInt( event.target.value);

}


tax(event)
{
  this.otax = parseInt( event.target.value);

}

monthly()
{
this.m= this.bs + this.hra + this.otax;

}

annual()
{
this.y= (this.bs + this.hra + this.otax)*12;

}

incometax()
{
  if(this.y<=300000)
  {
    this.inc=0;
  }
  else if(this.y>=300000 && this.y<=700000)
  {
    this.inc=this.y-((this.y*10)/100);
  }
  else
  this.inc=this.y-((this.y*20)/100);
}
}
