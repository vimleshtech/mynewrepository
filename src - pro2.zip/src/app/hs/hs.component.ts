import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hs',
  templateUrl: './hs.component.html',
  styleUrls: ['./hs.component.css']
})
export class HsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
