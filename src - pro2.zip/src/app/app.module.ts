import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import {ItComponent} from './it/it.component'
import {FsComponent} from './fs/fs.component'
import {HsComponent} from './hs/hs.component'
import {CalcComponent} from './calc/calc.component'

@NgModule({
  declarations: [
    AppComponent,FsComponent,HsComponent,ItComponent,CalcComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
