import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fs',
  templateUrl: './fs.component.html',
  styleUrls: ['./fs.component.css']
})
export class FsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
