def reducer(content):
     reduce=[]
     for w in content:
          #print(w)
          flag = 1
          mind  = -1
          for line in reduce:
               mind= mind+1
               if line[0] == w:
                    flag = 0
                    break


          if flag == 0:
               reduce[mind][1]= int(reduce[mind][1])+1
          else: # for new keyword
               wo=[]
               wo.append(w)
               wo.append(1)
               
               reduce.append(wo)
          

     return reduce          
