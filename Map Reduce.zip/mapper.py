def mapper(line,sep):
     words = line.split(sep)
     return words

     
