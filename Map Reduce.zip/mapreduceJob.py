import mapper as m
import reducer as r


data=["this is python test program","this is map reduce demo example","python is very simple for map reduce implementation","my first python map reduce example"]

content = []
for line in data:
     words = m.mapper(line,' ')    
     
     for w in words:
          content.append(w)
     
print(content)

result = r.reducer(content)
for d in result:
     print(d)
     

     


     
     



