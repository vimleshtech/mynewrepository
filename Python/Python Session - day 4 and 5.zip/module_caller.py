### example :1 
'''
import Module1    # import/load all functions
Module1.wel()
o = Module1.getNum()
print('return value is : ',o)
'''

### example :2
from Module1 import wel,getNum  # import selected function
wel()
o = getNum()
print('return value is : ',o)


### example :3
import Module1 as m # create alias o Moudle1
m.wel()
m.add(11,333)

#### call to function which can take default value
m.mul(12,3,2)













