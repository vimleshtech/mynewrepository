import os

f = os.listdir(r"C:\Users\vkumar15\Desktop\Ansible Yml")

#print(f)
for f1 in f:
     c = f1.split('.')
     if c[1] == 'txt':
          print(f1)
 


## string function 
name = 'NITIn srivastava'
l = len(name)
print('count of char : ', l)
u = name.upper()
print(u)
l = name.lower()
print(l)
### slicer
print(name[0:4])  # 0 to 3
print(name[2:4])  # 2 to 3
















           






