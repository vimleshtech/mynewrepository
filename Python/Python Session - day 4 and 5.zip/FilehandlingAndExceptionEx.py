

data = open(r'C:\Users\vkumar15\Desktop\data.txt','r')

log = open(r'C:\Users\vkumar15\Desktop\log.txt','w')


data.readline()

row = data.readlines()
sal = 0
rn = 0

for r in row:
     rn = rn+1
     
     c = r.split(',')
     try:
          
          sal = sal +int(c[2])
     except:
          log.write('INVALID DATA : at row number '+str(rn)+' '+r+'\n')
          print('INVALID DATA : at row number '+str(rn)+' '+r+'\n')


print('total sal :',sal)
log.close()
     

###
a =[333,323,22,21,2,2333]
max(a)
min(a)
sum(a)
a.sort()











