# function : is set of instruction or command which is reusable
# there are following types of functions

# i. no argument, no return 
def wel():
     print('welcome to function .... world..Hello ')
     
#ii. no argument with return 
def getNum():
     a =11
    
     return a

#iii. argument/parameter with no return 
def add(a,b):
     c= a+b
     print(c)

#iv. argument with return 
def sub(a,b):
     c =a-b
     return c

####### default value in function
def mul(a,b,c=0,d=0):
     #e =a*b*c*d
     
     if c>0 and d>0:
          e = a*b*c*d          
     elif c>0: 
          e = a*b*c
     elif d>0:
          e = a*b*d

     else:
          e = a*b          
     
          
     print('output is :',e)



     


     





     
     
     
