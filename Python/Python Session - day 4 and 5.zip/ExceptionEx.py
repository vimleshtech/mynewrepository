'''
Exception/Error Handing:

Exception : is runtime error which may or may not occur
Handling : to tackle the error when that will occur

-to prevent to code from failure due to single error
-customize the error message
-to maintain the log



'''
n = int(input('enter number :'))
d = int(input('enter number :'))

try:     
     o = n/d
     print('output  = ',o)
except:
     print('invalid input ')
     

#### 2nd logic
a =1
b =33
c = a+b


print(c)


