## finle handling
'''
open('path',mode)
mode:
     r : read
     w : write
     a : append
     w+: write and read  
     a+: append and read
functions:
     read() : read all contents
     readline() : read first line
     readlines() : read line by line and convert in list 
     write() 
     close() 
     
'''

f = open(r'C:\Users\vkumar15\Desktop\Ansible Yml\dir2.txt','r')

#print(f.read())
#print(f.readline())

# print(len(f.readlines())) # print row count 

c = f.readlines()# [row1,row2,row3]
rc = 0
wc = 0
for r in c:
     
     #print(r)
     w = r.split(' ')
     wc = wc+len(w)
     rc = rc+1
     

print('no. of rows in file :',rc)
print('no. of word s in file :',wc)

f.close()


### write to file
f1 = open(r'C:\Users\vkumar15\Desktop\Ansible Yml\log.txt','w')
f1.write('no. of rows in file :'+str(rc))
f1.write('no. of word s in file :'+str(wc))


f1.close()




     
