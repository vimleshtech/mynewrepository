from Tkinter import *
 
window = Tk() 
window.title("Welcome to LikeGeeks app") 
window.geometry('600x400') 


lbl = Label(window, text="Hello") 
lbl.grid(column=0, row=0)


lblmsg = Label(window) 
lblmsg.grid(column=0, row=2)
 
 
txt = Entry(window,width=20) 
txt.grid(column=1, row=0)
 
def clicked(): 
    res = "Welcome to " + txt.get()
    print 'you have clicked on button ',res
    lblmsg.configure(text= res)
 
btn = Button(window, text="Click Me", command=clicked) 
btn.grid(column=2, row=0)
 
window.mainloop()
