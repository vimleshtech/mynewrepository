import threading
import time 


def test1():
    for x in range(1,5):
        print 'Process -1 ',x
        time.sleep(3)

def test2():
	for x in range(1,5):
		print 'Process -2 ',x
		time.sleep(3)


#create process
p1 = threading.Thread(name='test1', target=test1)
p2 = threading.Thread(name='test2', target=test2)

p1.start()
p2.start()

#test1()
#test2()

		

