
class a:

     def add(s,a,b):
          c =a+b
          print(c)


     def add(s,a,b,c):
          d = a+b+c
          print(d)

o = a()
o.add(1,2)#error 
#o.add(22,33,44)
