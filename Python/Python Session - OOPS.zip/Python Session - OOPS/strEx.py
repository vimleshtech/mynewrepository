s = "String Handling is good"
print(s)  # "String Handling"
print(s[0:4])  # slicing  # str  : 0 to 4-1


#
c = s.split(" ") # c=[string,handling,is,good]

print(c) #print all elements
print(c[0]) # print first element 

### replace
c = s.replace("i","xyz")

print(c)

###
le = len(s) # count of chars..
print(le)

#print in reverse order
for i in range (le-1,-1,-1):  # 10 to  0  , -1
     print(s[i],end='')



     






     
     





