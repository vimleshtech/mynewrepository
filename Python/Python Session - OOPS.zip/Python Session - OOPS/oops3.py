class users: # class     
     def IT(s,sal):          

          #print(s.s1,s.s2,s.s3)
          
          if sal<s.s1:
               s.tax = 0
          elif sal<s.s2:
               s.tax = (sal-s.s1)*.05               
          elif sal<s.s3:
               s.tax = s.s1*.05+ (sal-s.s2)*.20
          else:
               s.tax = s.s1*.05+ s.s2*.20 + (sal-s.s3)*.30
          print('Tax amount : ',s.tax)
       
     #constructor      
     def __init__(s,country): # when object will create
          print('test',country)
          
          if country == "india":
               s.s1 = 300000
               s.s2 = 500000
               s.s3 = 1000000
          elif country == "us":
               s.s1 = 700000
               s.s2 = 1500000
               s.s3 = 3000000
          elif country == "uk":
               s.s1 = 600000
               s.s2 = 1000000
               s.s3 = 2000000

          #print(s.s1,s.s2,s.s3)
          
               

o = users('india')
o.IT(900000)



     
