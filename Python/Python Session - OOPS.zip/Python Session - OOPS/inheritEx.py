class cal: # parent class
     def add(s,a,b):
          c = a+b
          print(c)
     def sub(s,a,b):
          c = a-b
          print(c)


class dcalc(cal): # child class
     def mul(self,a,b,c):
          d = a*b*c
          print(d)

          
               

o = dcalc()  # object of child class
o.add(11,2) 
o.mul(11,2,3)
o.sub(33,3)
