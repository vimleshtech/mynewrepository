name ="nitin sinha"

#word reverse
w = name.split(" ")

for e in range(len(w)-1,-1,-1):  # len-1 ,  0 , -1
     print(w[e])
     
     

