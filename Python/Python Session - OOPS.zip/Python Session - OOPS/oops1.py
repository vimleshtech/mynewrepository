class users: # class
     def newUser(s):  # function 
          s.uid = input('enter id :')
          s.name = input('enter name :')
          s.pwd = input('enter pwd :')

     def show(s):  # function 
          print('***** User details ****** ')
          print('uid : ',s.uid,'\t name : ',s.name,'\t pwd: ',s.pwd)
          
#create object : copy of class
o1 = users()
o2 = users()

o1.newUser()
o2.newUser()

o2.show()


          

o1 = users()
