class users: # class
     
     def newUser(s):  # function 
          s.uid = input('enter id :')
          s.name = input('enter name :')
          s.pwd = input('enter pwd :')
          print(s)

     def show(s):  # function 
          print('***** User details ****** ')
          print('uid : ',s.uid,'\t name : ',s.name,'\t pwd: ',s.pwd)

     #constructor      
     def __init__(s): # when object will create
          s.uid = 0
          s.name ='guest user'
          s.pwd ='na'
          print('*** Class information : This class contains following functions : ')
          print('i. newUser(): take input for user, ii. show(): print existing details ')
     #deconstructor
     def __del__(s):
          print(s,' is deleted')
          
          
          
#create object : copy of class
o1 = users() # constructor will be invoked by default 
o2 = users()
o1.show()
#o1.newUser()
#o2.newUser()

del o1
o1.show()




