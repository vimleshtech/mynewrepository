import clac

class aclac(clac.compute):

        def mul(s,a,b):
             d = a*b
             print(d)

             
     
