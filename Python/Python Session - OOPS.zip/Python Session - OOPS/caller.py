'''
import clac

o = clac.compute()
o.add(111,3)
o.sub(43,3)
'''
import calc1

a = clac1.aclac()
a.mul(11,2)
a.add(2,3)


