class test:

     def add(s,a,b,c=0,d=0): # default value : c=0,d=0
          m = a+b+c+d
          print(m)



o = test()
o.add(11,2)
o.add(11,2,3)
o.add(11,2,433,34)
