class compute:
     def add(s,a,b): # 3 argument 
          c = a+b
          print(c)

     def sub(a,b,c):
          d = b-c
          print(d)

          
