# class 
class emp:

     #methods / function s
     def newEmp(s):
          s.id = 1
          s.name ='raman'

     def show(s):
          print(s.id)
          print(s.name)

     def __init__(self):
          print('object is created ',self)
          

     def __del__(s):
          print('object is deleted ',s)         


a=[]
for i in range(0,5):
     o = emp()
     o.newEmp()
     a.append(o)

print(a)

'''
o = emp() # create object 
o.newEmp() # invoke / call to the functioh n
o.show() 

del o

#o.show()

'''



