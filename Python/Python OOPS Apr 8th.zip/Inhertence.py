class clac:
     def add(s,a,b,c=0):
          d =a+b+c
          print(d)

     def sub(s,a,b):
          c = a-b
          print(c)
     



class dcalc(clac):

     def mul(self,a,b):
          d = a*b
          print(d)

class tax(dcalc):
     def taxcal(d,sal):
          if sal<300000:
               print('no tax')
          else:
               print('taxable income')



class student:
     def newstu(ss,i,name):
          print(i)
          print(name)


class marks(student):
     def mark(s,hs,es,cs):
          total = hs+es+cs
          print(total)
          

#object
'''
o = dcalc()
o.mul(11,2)
o.add(22,3)
o.sub(33,2)
'''

t = tax()
t.taxcal(3222222)
t.add(22,33)
t.add(111,22,3)



s = marks()
s.newstu(221,'nitin')
s.mark(66,77,88)





