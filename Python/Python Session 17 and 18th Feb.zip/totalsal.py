'''
exception handling:
     exception  : is error which may or may not occur
     handling   : when exception will occur the manage or customize error


-customization error message
-prevent the code from failure due to single error

'''


data = open(r'C:\Users\vkumar15\Desktop\data.txt','r')
w = open(r'C:\Users\vkumar15\Desktop\error.txt','w')


s = 0
ci = 0
for i in data.readlines():
     ci =ci+1   
     c = i.split(',')
     try:
          
          s = s+ int(c[1])
     except:
          print('invalid data at row numebr : ',ci , i)
          w.write(i+' @ row number '+str(ci)+'\n')
          

print('total sal :',s)
w.close()

     
