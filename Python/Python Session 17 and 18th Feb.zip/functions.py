# function with argument and return 
def add(a,b):
     c =a+b
     return c

#fucntion with argument but no return

def sub(a,b):
     c =a-b
     print(c)
     

# no argument no return 
def wel():
     print('welcome...')

# no argument with return 
def show():
     return 100

     
