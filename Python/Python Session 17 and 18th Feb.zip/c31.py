s ='abc'
le = len(s)

for i in range(0,le,1):
     st = s[i]
     
     for j in range(i+1,le):
          st =st+ s[j]

     ind = 0
     for k in range(1,i+1  ):
          st =st+ s[ind]
          ind=ind+1
     print(st)
     
