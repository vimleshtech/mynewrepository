#() tuple
#[] list
#{} dict

## create function
def add(a,b):
     print (a+b)


## function with default argument/optional argument
def add1(a,b,c=0,d=0,n=0):
     print (a+b+c+d+n)


#function to take list reference
def add2(li):
     s = 0
     for i in li:
          s = s+ i
          
     print (i)



add('1','2')

add1(11,22,33)

#     
add2([1222,212,2,22,32,2,2,2,2])
a = [1222,212,2,22,32,2,2,2,2]
add2(a)




for i in range(1,10):

     if i % 4 == 0:
          #break
          continue

     print(i)
     

# type casting
'''
python version 3.+...
-default data type is string when data will read from console or file system

python version <3
          -default data type will as it is when data will read from console 
                         1    - int
                         '1'  - str 
           
'''
n1 = input('enter data ')
n2 = input('enter data ')

print(type(n1))
print(type(n2))


n = n1+n2
print(n)

#type cast 
n = n1 +str(1)

print(n)


n = int(n1) +1


print('output is ', n)
print('output is '+str( n))

print(1+2+n)








           
