'''
r - read
w - write
a - append
a+ - append and read
w+  - read and write
etc.

'''


data = open(r'C:\Users\vkumar15\Desktop\Ansible - Path.txt','r')

'''
function :
     read() - read entire file
     readline() - read first line of file
     readlines() - read entire file and conver to list
     write()
     close()
     
'''
#d = data.read()
#d = data.readline()
d = data.readlines()
for i in d:
     print(i)

'''
q. wap to show count of "all"
q. wap to get count of files from one directory

'''


     





