### 

'''
import functions

c = functions.add(1,1)
print(c)
'''

'''
from functions import add,sub

a = add(1,3)
print(a)

sub(33,3)

'''
import functions as f

f.add(33,3)
f.sub(3,4)






