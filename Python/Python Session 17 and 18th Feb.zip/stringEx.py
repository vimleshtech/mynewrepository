'''
()   : tuple, function , conditon 
[]   : list / array / [index]
{}   : dict /dictionary 
'''
s = input('enter data :')

l = len(s)

print(l)

s1 = s[0:3] #pyt

print(s1)


s1 = s[3:5] #3,4

print(s1)

###
a = s.replace('a','bcd')
print(a)

#######
l = list(s) # [p,y,t,h,o,'n']

print(l)

print(l[1])

for i in l:
     print(i)
#reverse
for j in range(len(l)-1, -1, -1):
     print(l[j],end='')
     


print()
data ="this is python"
#print(data)
d = data.split(' ') # [this,is,python]
print(d)
print(d[1])









