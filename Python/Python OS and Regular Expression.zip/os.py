import os
"""
#print(os.listdir("C:\\Users\\vkumar15\\Desktop\\"))

## read all files from one directory and write to one master file 
for f in os.listdir("C:\\Users\\vkumar15\\Desktop\\"):
     

     c = f.split(".") # [abcd,txt]
     if len(c)>1:
          if c[1] == "txt":
               print(f)
"""          




for f in os.listdir(r"C:\Users\vkumar15\Desktop\Compiler"):
     n = f.split("\n")
     for k in n:
          file = open(r"C:\Users\vkumar15\Desktop\Compiler\" + k )
          print(file.read)
     




#print(os.curdir)

#os.remove("path")
#os.mkdir("test")

##########
#import time

#print(time.time() )

#
#import re #regular expression
# match()
# search()
# groups()










