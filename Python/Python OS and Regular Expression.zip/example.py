# wap to search lost file in os /in any drive
# wap to move all .txt files from one folder to another file
# wap to show file name, those file contain python word

import os
import re


regex = r"([a-zA-Z0-9$_@.]+)(@gmail.com)"

out = open(r'C:\Users\vkumar15\Desktop\out.txt','w')

for f in os.listdir(r"C:\Users\vkumar15\Desktop\Compiler"): # read all files 
     s = r"C:\Users\vkumar15\Desktop\Compiler\\"+f #append path +file name 
     
     data = open(s,'r')  # read file 
     for file in data.readlines():  # read data and convert to list 
                   
                   if re.search(regex, file.replace("\n","")):
                        #print('match ')
                        #print(file)
                        out.write(file+str("\n"))
                        

     data.close()


out.close()

    
                    
     
