import re
'''
\d   : 0 to 9
[0-9]
\w    : chars
\D    : non digit
\W    : non char


"([A-Za-z]+) (\d)"
[01234569]
[0-69]
[a-mz]

'''
regex = r"([0-69#$]+) (\d+)"


if re.search(regex, "1234# 24"):
    print('match ')
    
    # Indeed, the expression "([a-zA-Z]+) (\d+)" matches the date string
    
    # group() method to get all the matches and captured groups.
    match = re.search(regex, "June 24")
    
    # This will print [0, 7), since it matches at the beginning and end of the 
    # string
    print("Match at index %s, %s" % (match.start(), match.end()))
    
    # The groups contain the matched values.  In particular:
    #    match.group(0) always returns the fully matched string
    #    match.group(1), match.group(2), ... will return the capture
    #    match.group() is equivalent to match.group(0)
    
    # So this will print "June 24"
    print("Full match: %s" % (match.group(0)))
    # So this will print "June"
    print("Month: %s" % (match.group(1)))
    # So this will print "24"
    print("Day: %s" % (match.group(2)))
else:
    # If re.search() does not match, then None is returned
    print("The regex pattern does not match. :(")


    
