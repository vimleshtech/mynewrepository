import mysql.connector as a  # here mysql is package / library , and connector is class 


#here con is object, and connect is inbuilt function
#host : server = localhost 
con = a.connect(host='localhost',database='supermarket',user='root',password='root')


#print(con)

cur=con.cursor() # con is object of connection, and cursor is inbuilt function to execute sql statement


#empid = input('enter id to be search :')

#cur.execute("select * from sales;")  # run/execute sql command 

cur.execute("select s.oid,c.cname,p.pname,s.quantity*p.price as total_price from sales as s inner join custoer as c on s.cid = c.cid  inner join product as p 	on s.pid  = p.pid;");

print(cur)

results = cur.fetchall()  # read data from cur and store on result list

#print results 


for row in results:
    print row[1], row[2],row[3]


con.close()

