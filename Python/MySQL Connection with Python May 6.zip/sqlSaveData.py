import mysql.connector as a  # here mysql is package / library , and connector is class 


#read data from text file
f = open(r'C:\Users\aayushi\Desktop\emp.txt','r')

for row in f.readlines():
    print row

#here con is object, and connect is inbuilt function
#host : server = localhost 
con = a.connect(host='localhost',database='supermarket',user='root',password='root')


#print(con)

cur=con.cursor() # con is object of connection, and cursor is inbuilt function to execute sql statement




#cur.execute("insert into custoer(cname) values('ayush');");

name = input('enter name : ')

cur.execute("insert into custoer(cname) values('"+name+"');");


con.commit() # insert, delete , udpate


print 'data is saved'

con.close()

