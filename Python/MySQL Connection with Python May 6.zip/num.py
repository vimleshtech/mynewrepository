import numpy as np 
a = 'hello world' 
print a
p = np.array([1,2,3]) 
print p
q = np.array([[1, 2], [3, 4]]) 
print q
m = np.array([1, 2, 3], dtype = complex) 
print m
n = np.array([1, 2, 3,4,5], ndmin = 2) 
print n
dt = np.dtype([('age',np.int8)])
# file name can be used to access content of age column 
a = np.array([(10,),(20,),(30,)], dtype = dt) 
print a['age']

