try:
          
     n = int(input('read data :'))
     d = int(input('read data :'))


     o= n/d

     print(o)
except:
     print('invalid input')
     
a = [1,2,3,34]

for i in a:
     print(i)
     
    
