a=[22,333,2223,33232,22333,44332322,333]

print(max(a))
print(min(a))
print(sum(a))
a.sort()
print(a)

