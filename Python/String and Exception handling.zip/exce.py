# exception handling
# exception : is run time error which may or may not occur
# handling: is tackle the error if occur

try:
     
     n =int( input('enter data '))

     d =int( input('enter data '))
except ValueError as v:
     print(v)
     
except:
     print('invalid data')
     
try:

     o = n/d

     print(o)
     
except :
     print('inalid input')
     
