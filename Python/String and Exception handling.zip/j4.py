class student:

     def getData(s):
          s.rno = input('enter roll no :')
          s.name = input('enter name :')
          s.marks = []
          for i in range(0,5):               
               m = int(input('enter marks :'))
               s.marks.append(m)

     def calc(s):
          s.total = 0
          for m in s.marks:
               s.total = s.total+m

          s.avg = s.total/5
          s.grade =''
          
          if s.avg>=80:
               s.grade ='A'
          elif  s.avg>=60:
               s.grade ='B'          
          elif  s.avg>=50:
               s.grade ='C'
          else:
               s.grade ='D'               
               
     def disp(s):
          print('roll no = ',s.rno)
          print('roll name = ',s.name)
          print('roll total = ',s.total)
          print('roll avg = ',s.avg)
          print('roll grade = ',s.grade)
          

     

stus = []
for i in range(0,2):     
     o = student()    
     o.getData()
     
     stus.append(o)
     
for s in stus:
       s.calc()  
       s.disp()
     





     
