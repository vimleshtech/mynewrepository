s = input('enter data :')


print(s[1:4])
print(s[0:4])
print(s[:4])
print(s[3:])

d  =list(s)
print(d)

sc =0

dig=['0','1','2','3','4','5','6','7','8','9']

for c in d:
     #if c == 's':
     if c in dig:
          sc=sc+1


print(sc)





          
