s = input('enter data :')

d = s.split(' ')


f = 0
cc = 0
for c in d:     
     if c =='raj':
          f =1

     if f ==1:
          cc=cc+1
          


print(cc)





          
