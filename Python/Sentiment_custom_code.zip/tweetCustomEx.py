f = open(r'C:\Users\vkumar15\Desktop\tweet.txt','r')
k_p = open(r'C:\Users\vkumar15\Desktop\mylib.txt','r')
k_n = open(r'C:\Users\vkumar15\Desktop\mylib2.txt','r')

keys=[]
keys_n=[]

for key in k_p.readlines():
     keys.append(key.replace('\n',''))     

for key in k_n.readlines():
     keys_n.append(key.replace('\n',''))
     
k_p.close()
k_n.close()

def clean_data(d):
     bad_key = ['@','_','$','$']
     for k in bad_key:
          d = d.replace(k,'')
     return d

def get_pwords():
     return keys

def get_nwords():
     return keys_n

def get_words():
 words = []
 for r in f.readlines():

     r = clean_data(r.replace('\n',''))
     c = r.split(' ')  # line to words 
     for ck in c:
          kp=ck.split(':') # key : value , to pick value only 
          #print(kp,len(kp))
          if len(kp)>1:
                    #print(kp[1],ck)
                    ck=kp[1]
                    
          elif len(kp) ==1 :
                    #print(kp[0],ck)
                    ck=kp[0]
                    
          words.append(ck)
          
          if ck not in keys:
               print(ck)
                             
 return words

##################################################               



     
     

