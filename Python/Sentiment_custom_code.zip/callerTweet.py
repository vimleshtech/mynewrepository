from tweetCustomEx import get_pwords,get_nwords,get_words


p = get_pwords()
n = get_nwords()

w = get_words()

print(w)
l = len(w)
pc =0
nc =0
for kw in w:
     if kw in p:
          pc=pc+1
     if kw in n:
          nc=nc+1


pp = pc/l
np = nc/l

print('positive : ',pp)
print('negative : ',np)



     
          
