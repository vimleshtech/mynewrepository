#Inputs
a=int(input('Enter a:'))
b=int(input('Enter b:'))
c=int(input('Enter c:'))
d=int(input('Enter d:'))

#Check

e=(a*a*a)+(b*b*b)+(c*c*c)
print('Value of e:',e)


f=(d*d*d)
print('Value of f:',f)

if e==f:
     print('Equation Satisfied')
else:
     print('Not Satisfied')
