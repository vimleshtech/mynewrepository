#q. WAP to show count rows from file
f=open(r'C:\Users\vkumar15\Documents\emp.txt','r')

count=0
#print(len(f.readlines()))

for r in f.readlines():
     count=count+1
print('Number of rows',count)
f.close()

#q. wap to show count of word from file
f=open(r'C:\Users\vkumar15\Documents\emp.txt','r')
count=0
for r in f.readlines():
  col= r.split(',')
  count=count+len(col)

print('Number of words in the file',count)

f.close()


#q. wap to show count of particular word from file
f=open(r'C:\Users\vkumar15\Documents\emp.txt','r')
count=0
w=str(input('Enter the word to be matched'))

d = []
for r in f.readlines():
  col= r.split(',')# ['is','a']
  d.append(col[2])
  for p in col:
       if(p==w):
         count=count+1
print('Number of times of the particular word in the file',count)
f.close()

for a in d:
     print(a)
     
#q. wap to show data in below format:
'''    emp.txt
       id,name,gender,salary
        1,aaa,m,32222



        output:
          m = 10
          f = 3
'''
f=open(r'C:\Users\vkumar15\Documents\emp.txt','r')
countm=0
countf=0
for r in f.readlines():
  col= r.split(',')
  if(col[2]=='m'):
     countm=countm+1
  else:
     countf=countf+1
print('Number of males,m:',countm)
print('Number of males,f:',countf)
f.close()
