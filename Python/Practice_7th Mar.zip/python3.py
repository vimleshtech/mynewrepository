a =int(input('enter data  :'))
b =int(input('enter data  :'))
c =int(input('enter data  :'))

# print if no. is even
# if condition 
if a%2 == 0:
     print('even no.')



#if else
if a%2 == 0:
     print('even')
else:
     print('odd')


#if else if
if a>b and a>c:
     print('a is gt')
elif b>a and b>c:
     print('b is gt')
else:
     print('c is gt')
     

#nested if else: if inside if condition 
if a>b:
     if a>c:
          print(' a is gt')
     else:
          print('c is gt')
else:
     if b>c:
          print('b is gt')
     else:
          print('c is gt')
          
     
print('end of program')


     
