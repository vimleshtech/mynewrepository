a =1 # int
print(type(a))

"""
a =11.1 # int
print(type(a))

a = '1' #str
print(type(a))

a = True # boolean
print(type(a))

a = [1,2,3,3] #list
print(type(a))

a = ('sun','mon') #tuple
print(type(a))

a = {1:'one',2:'two'} #dictionary
print(type(a))

"""

