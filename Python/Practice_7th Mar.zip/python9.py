#Input Salary
sal=int(input('Enter salary of a person:'))

#Check salary
if sal>=0 and sal<7500:
     it=sal*0.2
elif sal>=7500 and sal<=8999:
     it=sal*0.3
else:
    it=sal*0.4

print('Income tax is:', it)
