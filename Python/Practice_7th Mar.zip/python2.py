a =int(input('enter data  :'))
b =int(input('enter data  :'))


print(type(a))
print(type(b))

c= a+b

#print(c)
print('sum of two numbers =',c)

