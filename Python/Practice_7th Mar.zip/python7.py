#Input marks of a student
a=int(input('Enter a:'))
b=int(input('Enter b:'))
c=int(input('Enter c:'))
d=int(input('Enter d:'))
e=int(input('Enter e:'))

per=((a+b+c+d+e)/500)*100
print('Percentage',per)


#condition

if per>=60:
     print('First Division')
elif per>=50 and per<=59:
     print('Second Division')
elif per>=40 and per<=49:
     print('Third Division')
else:
     print('Fail')
