for i in range(1,10): # 1 - init, con  10 , default increment is 1
     print(i)
     

for i in range(1,10,2): 
     print(i)
     
#reverse

for i in range(10,0,-1): 
     print(i)
     
