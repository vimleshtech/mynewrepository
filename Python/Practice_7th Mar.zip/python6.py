#Input Salary
sal=int(input('Enter salary of a person:'))

#Check salary
if sal>=5000 and sal<=10000:
     hra=sal*0.1
     da=sal*0.05
     print('HRA is:', hra)
     print('DA is:', da)
elif sal>=10001 and sal<=15000:
     hra=sal*.15
     da=sal*0.08
     print('HRA is:', hra)
     print('DA is:', da)
else:
     print('Not valid input')
     
