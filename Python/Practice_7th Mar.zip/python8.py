#Input unit
unit=int(input('Enter no of units:'))

#Condition
if unit>=0 and unit<=100:
     ch=unit*0.4
elif unit>=101 and unit<=300:
     ch=unit*0.5
else:
     ch=unit*0.6

total=ch+50
print('Total Charge is:', total)
