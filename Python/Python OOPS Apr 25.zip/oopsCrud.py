class emp:

     def newEmp(self):
          print(self)
          self.id  = input('enter eid :') # global variable/public
          self.name  = input('enter name :') # global variable/public

          #can access within same function 
          #sal  = input('enter salary :') # local or private variable


          self.sal  = input('enter salary :') # global

     def disp(self):
          print(self)
          print('Employee id : ',self.id)
          print('Employee Name : ',self.name)
          #print('Employee Salary : ',sal)  # cannot access

          print('Employee Salary : ',self.sal)  # cannot access
     def __init__(s):
          print('object is created :\n this class contains following methods i. newEmp() 2. disp()')
          
     def __del__(s):
          print(s, ' is deleted ')
          
          
'''
e= emp()
e.newEmp()
e.disp()
'''

emps = [] #declare empty list
for i in range(0,5):
     e = emp()
     e.newEmp()
     emps.append(e)
     
#print addresss
print(emps)


#enter index to print data
ind = int(input('enter index '))

print(emps[ind].disp())

del emps[i]

print(emps[ind].disp()) #will not execute 




     
     





