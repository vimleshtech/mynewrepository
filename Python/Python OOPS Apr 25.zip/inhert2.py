from inherit import calc


class ecalc(calc):
     def mul(a,b,c):
          d = b*c
          print(d)

class d(ecalc):
     def mul(s,a,b):
          print('test')
          

     def mul(s,a,b): # overriding

          d = a*b
          print('mult = ',d)

     def newSum(s,a,b,c=0):  # here c is default variable
          d = a+b+c
          print(d)

          
          

o = d()
o.add(11,2)
o.mul(33,3)
o.newSum(112,2)
o.newSum(112,2,333)



