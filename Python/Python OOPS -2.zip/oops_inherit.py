class calc:

     def add(s,a,b):
          print(a+b)
          d =1
          
     def sub(s,a,b):
          #pritn(d)
          
          return a-b
     

     def mul(s,a,b):
          print(a*b)

     def dif(s,a,b):
          print(a/b)


class mcalc(calc):
     def pow(s,a,b):
          print(a**b)


#class abcd(clac):
     

o= mcalc()
o.add(11,3)
a = o.sub(222,3)

o.pow(a,3)

o.mul(33,4)




          
     


          
