
'''
85/10 = 8.5
85%10 = 5


'''
for i in range(1,10):

     if i % 3 == 0:
          #break # to terminate to iteration
          continue # skip the current iteration 
     
     print(i)
     
