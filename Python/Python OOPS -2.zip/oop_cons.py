#here self is reference of current object, however self is not inbuilt keyword
class calc:

     #python doesn't support function overloading
     def __init__(self): # this function will override 
          print('object is created ',self)

     def __init__(self,a,b):
          self.a= a  # self.a : global or instance variable, a is local
          self.b= b
          
          print('object is created ',self)
          

     def add(ob,a,b):
          print(ob.a)
          
          print(a+b)

     def sub(self,a,b,c=0):   # c is variable and 0 is default value
          d = a-b-c
          return d
     def wel(s):
          print('welcome to class world ')
          
          
     def __del__(s):
          print('object is deleted :',s)
          

o = calc(11,22)


o.add(11,2)

a = o.sub(333,2)
print(a)
a = o.sub(333,2,33)
print(a)


del o



o.add(1,2) # will not work 

