a =1
b =22
c = a+b
print(c)
