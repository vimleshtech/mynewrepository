#(5)	(1)+(1+2)+(1+2+3)+(1+2+3+4)…………..up to n terms**

for r in range(1,10):

     print('(',end='')
     
     for c in range(1,r+1):
          if c<r:
               print(c,end='+')
          else:
               print(c,end='')
     print(')+',end='')
###
a = input('enter name  :')

d = list(a)
print(d)

c = ''
for e in d:
     c =c+e
     print(c)
     
     
