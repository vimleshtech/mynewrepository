data = open(r'C:\Users\vkumar15\Desktop\emp.txt','r')

#print(data.read())

#print(data.readline())

#print(data.readlines())

s = 0

for r in data.readlines():
     col = r.split(',')
     s = s+ int(col[3])

print('total sal = ',s)

     


