'''
1 2 3  | i =1 c = 1 2 3 
1 2 3  | i =2 c = 1 2 3 
1 2 3  | i =3 c = 1 2 3 
1 2 3  | i =4 c = 1 2 3

1
12
123
1234

1234
123
12
1

'''


for i in range(1,5):

     for c in range(1,4):
          print(c,end='')

     print()
          
###     
for i in range(1,5):

     for c in range(1,i+1):
          print(c,end='')

     print()

