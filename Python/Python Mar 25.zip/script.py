# single line comment
'''
multiple line comment 

'''
"""

"""

#python does allocate memory automatically
a =1   #int
print(type(a))

a=1.2 #float
a='a' #str
a=True #bool
a=[11,222] #List
a=(1,2) # tuple
a={'a':'alpha'} #dict

