f =open(r'C:\Users\vkumar15\Desktop\Azure.txt','r')

#print(f.read())
#print(f.readline())
#print(f.readline())

#print(f.readlines())

r = f.readlines()

print('row count ',len(r))
ri  =0
wc = 0

for d in r:
     col=d.split(' ')
     wc = wc+len(col)
     
     print(d.upper())
     ri=ri+1

     

print('row count :',ri)     
print('word count :',wc)

#print(f)

