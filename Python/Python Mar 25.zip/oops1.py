class emp:
     
     def newEmp(s):
          print(s)
          s.eid = input('enter id ')
          s.ename=input('enter name ')
          

     def showEmp(s):
          print('emp id = ',s.eid)
          print('emp name = ',s.ename)
     def __init__(s):
          print('object is created ',s)
          
          

#####################

o = emp() # create object or instance of class emp
e = emp() # create object or instance of class emp

o.newEmp()
o.showEmp()

#e.newEmp()
