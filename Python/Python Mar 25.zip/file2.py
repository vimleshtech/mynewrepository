f =open(r'C:\Users\vkumar15\Desktop\Azure.txt','r')
f2 =open(r'C:\Users\vkumar15\Desktop\Azure1.txt','w')


r = f.readlines()
wc = 0
print(r)

for d in r:
     col=d.split(' ')
     for c in col:
          if c.replace('\n','') =="hi":
               wc=wc+1
               f2.write(d)


               
               
f2.close()
f.close()

     
     

   
print('word (hi) count :',wc)

#print(f)


'''
 male - 4
 female - 1


'''
