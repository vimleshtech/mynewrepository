f1 =open(r'C:\Users\vkumar15\Desktop\emp.txt','r')
f1.readline()
r = f1.readlines()
wc = 0
wc1 = 0
print(r)

for d in r:
     col=d.split(',')
     if col[2]=='male':
          wc=wc+1
     else:
          wc1=wc1+1
print("male",wc)
print("female",wc1)
          
              
               
     
f1.close()              

#print('Male count :',wc)     

               
               
f1.close()


    
