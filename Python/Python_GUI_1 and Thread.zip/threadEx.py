import threading
import time

def worker():
    for i in range(1,5):
         print('function -1 : ',i)            
         time.sleep(10)
    

def my_service():
    for i in range(1,5):
         print('function -2 : ',i)         
         time.sleep(5)

#process -1
t = threading.Thread(name='my_service', target=my_service)
#process - 2 
w = threading.Thread(name='worker', target=worker)


w.start()
t.start()


