import os, os.path

d = os.listdir(r'C:')

def readfile(dr):
     
     dd = os.listdir(dr)

     for a in dd:
          
          if os.path.isfile(a):
               print(a)
          
          else:
               readfile(a)
               
     

for a in d:
     #if a.split('.')[1]=='txt':
     if os.path.isfile(a):
          print(a)
     
     else:
          readfile(a)
     
