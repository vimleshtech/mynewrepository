nid = 100  # here nid is variable , and 100 is value  , int
name ='nitin'  # str 


print(nid) #print / output 
print(name)


### input from user
hs = input('enter data : ')   #### python 3.0+ version ,  default datatype is str when data will read from consolse
ms = input('enter data : ')

total =int( hs)+ int(ms)

print(total)

