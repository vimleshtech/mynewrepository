#J2
class empl:
    def __init__(s):
        s.Ecode=0
        s.Ename=''
        s.BasicSal=0.0
    def input(self):
        self.Ecode=int(input('Enter the employee code: '))
        self.Ename=input('Enter the employee name: ')
        self.BasicSal=int(input('Enter the basic salary: '))
    def calc(s):
        s.hra=0.4*s.BasicSal
        s.da=0.2*s.BasicSal
        s.ta=0.1*s.BasicSal
        s.Gross=s.BasicSal+s.hra+s.da+s.ta
        s.it=0.2*s.Gross
        s.pf=0.1*s.Gross
        s.net=s.Gross-(s.it+s.pf)
        
    def disp(s):
        print('The details are:')
        print('The basic salary is: ', s.BasicSal)
        print('HRA: ',s.hra)
        print('DA: ',s.da)
        print('TA: ',s.ta)
        print('Gross Salary: ', s.Gross)
        print('Income Tax: ', s.it)
        print('Pf is: ',s.pf)
        print('Net Salary: ',s.net)



        
    

