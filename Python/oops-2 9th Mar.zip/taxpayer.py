#J3
class taxpayer:
    def __init__(s):
        s.pan=0
        s.name=''
        s.income=0.0
        s.tax=0.0
    def input(self):
        self.pan=int(input('Enter the pan number of the person: '))
        self.name=input('Enter the name: ')
        self.income=int(input('Enter the income: '))
    def calctax(s):
        if s.income<=100000:
            s.tax=0
        elif s.income <=200000:
            s.tax=0.1
        elif s.income <=500000:
            s.tax=0.15
        elif s.income >500000:
            s.tax=0.2
        else:
            print('Tax cannot be calculated')
    def disp(s):
        print('Income Tax: ', s.tax*s.income)
    


        
    

