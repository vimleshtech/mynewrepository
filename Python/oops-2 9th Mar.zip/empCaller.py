'''
a = [1,2,3,1,2]
a =[ [1,2,3,1,2], [1,2,3,1,2]]

a[1].sort()


'''
#import emp  as e
from emp import emp as e

#import emp

emps = [] # [objec1,object2,object3]
flag = True
while flag:

    flag = input('press y to add emp information and n for exit ')
    if flag == 'n':
        flag = False
    elif flag == 'y':
        o = e()
        o.newEmp()
        o.calc()
        emps.append(o)
        flag = True 
    else:
        flag = True
        print('invalid choice, please select again.....!!!')

flag2=True
while flag2:
    flag2=int(input('Press 1 for search, 2 update, 3 for delete, 4 for displaying sorted data, 5 for displaying all record,6 to insert new record, and 0 to exit'))
    if flag2==0:
         flag2==False
    elif flag2==1:
        eid = input('enter employee id to be search :')
        for eo in emps:
            #print(eo)
            if eo.getEmpid() == eid:        
                eo.disp()
            else:
                print('No record found')
        flag2==True
    elif flag2==2:
         eid=input('Enter the employee number whose details you want to update:')
         for eo in emps:
             if eo.getEmpid()==eid:
                 eo.update()
         flag2==True
    elif flag2==3:
         eid=input('Enter the employee number whose details you want to delete:')
         for eo in emps:
             if eo.getEmpid()==eid:
                 eo.__del__()
                 emps.remove(eo)
         flag2==True
    elif flag2==4:
         print('See employees in order of their salaries:')
         sal=[]
         for i in range(0,len(emps)):
             for c in range(i+1,len(emps)):    
                 if emps[i].getSal() > emps[c].getSal():
                     t = emps[i]
                     emps[i] = emps[c]
                     emps[c] = t
         for eo in emps:
               eo.disp()
         flag2==True
    elif flag2==5:
         print('The details of all employees:')
         for eo in emps:
               eo.disp()
    elif flag2==6:
        o = e()
        o.newEmp()
        o.calc()
        emps.append(o)
        print('New record inserted')
        flag = True 
    else:
         flag2==True
         print('Invalid input. Please enter valid choice....')
         
         
