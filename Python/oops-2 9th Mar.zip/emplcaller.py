#J2
from empl import empl as e
empls=[]
c=10
i=0

print('Enter the details for 10 persons')
while i<c:
    print('Enter details of ',i+1,' person')
    o=e()
    o.input()
    empls.append(o)
    i=i+1

print('Displaying the information for all the 10 persons')
c=0
for i in empls:
    print('The details for ',c+1,' person are: ')
    i.calc()
    i.disp()
    c=c+1
    
