'''
inheritence: to extend one class featues to another class
                 there are following types of inheritence:
                         i. single level
                         ii. multi level
                             iii. tree
                             iv. hybrid
                                v. multiple 
polymorphisam:
    poly - many
    morhpisam - forms

        - multiple function have same name i.e. polymorphisam
            *python doesn't supprot oveloading
            *python does supprot overriding only 

'''
class a:
    def add(s,a,b):
        c =a+b
        print(c)


class b(a):
    def mul(s,a,b):
        print(a*b)


class x:
    def sub(s,a,b):
        print(a-b)

class m(a,x):
    def div(s,a,b):
        print(a/b)
    def div(s,a,b,c):
        print( (a+b)/c)


        
o = b()
o.add(11,2)
o.mul(33,3)


###
o1 =m()
o1.div(11,2,3)
o1.sub(22,3)
o1.add(33,2)





        
