#J2
from taxpayer import taxpayer as t
print('Enter details the person')
o=t()
o.input()
o.calctax()
o.disp()
        
