import socket  as ser             # Import socket module

s = ser.socket()           # Create a socket object

host = ser.gethostname() # Get local machine name # 192.168.1.22/ hp-pc
port = 1234                 # Reserve a port for your service.

s.bind((host, port))        # Bind to the port


s.listen(50)                 # Now wait for client connection.

while True:
   c, addr = s.accept()     # Establish connection with client.
   print 'Got connection from', addr
   c.send('Thank you for connecting')
   
   c.close()                # Close the connection

