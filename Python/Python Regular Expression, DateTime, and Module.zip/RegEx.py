import re
#line = "Cats  and mate are smarter than dogs python hi hello my name is"
#a = re.match( r'.* (.*?) python (.*?) .*', line, re.M|re.I)

line ="this is python abcd a abdc sjkhsjgshsf sgs"

a = re.match( r'(.*) python (.*?) (.*?) .*', line, re.M|re.I)

#a = re.match( r'(.*) @gmail.com', line, re.M|re.I)
#a = re.match( r'(.*) python (.*) is', line, re.M|re.I)
#re.search( r'(.*) python is', line, re.M|re.I)



#. : anything
#* : any number of times

if a:
   #print ("matchObj.group() : ", a.group()) # print all matching worords
   #print ("matchObj.group(1) : ", a.group(1)) #
   #print ("matchObj.group(2) : ", a.group(2))
   print('python found')
   
else:
   print ("No match!!")


      
