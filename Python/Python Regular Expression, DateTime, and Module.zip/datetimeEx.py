'''
import time

o = time.time()
print(o)
'''
import time

localtime = time.localtime(time.time())

print ("Local current time :", localtime)

print("today's date is : ",localtime[2],'/',localtime[1],'/',localtime[0])







