class emp:
     def newEmp(s):
          s.eid =int( input('enter id :'))
          s.name = input('enter name ')
          s.sal = input('enter sal ')         

     def getID(s):
          return s.eid 
     def IT(s):
         s.sal = int(s.sal)
         s.pa = s.sal*12

         if s.pa<300000:
              s.tax = 0
         elif s.pa<500000:
              s.tax = (s.pa-300000)*.05
         elif s.pa<1000000:
               s.tax =10000+ (s.pa-500000)*.20
         else:
               s.tax =110000+ (s.pa-1000000)*.30               
          

     def show(s):
          print('Emp id :',s.eid)
          print('Emp name :',s.name)
          print('Emp sal :',s.sal)
          #print(type(s.sal)) # show data type
          print('Total Anual Sal ',s.pa)
          print('Tax amount ',s.tax)
          

'''                            

i =1
while i<4:
     e=emp()
     e.newEmp()
     e.IT()
     e.show()
     i=i+1
'''

eo = []
i =1
while i<5:
     e = emp()  # creaate object 
     e.newEmp() # invoke to function
     e.IT()
     eo.append(e)

     i = i+1


#print(eo)
#eo[0].IT()
#eo[0].show()
'''
i =0
while i< len(eo):
     eo[i].show()
'''

sid = input('enter emp id to be search : ')

i =0
while i< len(eo):
     #print(eo[i].getID())
     if eo[i].getID() == int(sid):
          eo[i].show()

     i =  i+1




     







     


     
     



















