# create class
class compute:  # python is identation based programing language

     #function 
     def add(slef):
          print(slef)
          a = 1
          slef.b = 3
          slef.c = a+slef.b
          

     def show(s):
          print(s,s.b)
          print(s.c)
          

# create object
a = compute()
o = compute()

a.add()
o.add()

o.show()
a.show()







           
     
