#python does allocate memrory automatically
a =1 # int
a ='1' # str


def add():
     a =1
     b =3
     c =a+b
     
def show():

     print(c)

add()
show()


