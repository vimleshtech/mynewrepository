class emp:
     def newEmp(s):
          s.eid = input('enter data :')
          s.name = input('enter name ')
          s.sal = input('enter sal ')         

     def IT(s):
         s.sal = int(s.sal)
         s.pa = s.sal*12

         if s.pa<300000:
              s.tax = 0
         elif s.pa<500000:
              s.tax = (s.pa-300000)*.05
         elif s.pa<1000000:
               s.tax =10000+ (s.pa-500000)*.20
         else:
               s.tax =110000+ (s.pa-1000000)*.30
               
          

     def show(s):
          print('Emp id :',s.eid)
          print('Emp name :',s.name)
          print('Emp sal :',s.sal)
          #print(type(s.sal)) # show data type
          print('Total Anual Sal ',s.pa)
          print('Tax amount ',s.tax)
          
                  
          
e1 = emp()
e2 = emp()

e1.newEmp()
e2.newEmp()
e1.IT()
e2.IT()

e2.show()
e1.show()










