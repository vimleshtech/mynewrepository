'''
There are two types of loop:
i.  for
ii. while 

other type of loop:
     - nested loop : loop inside loop 
     
'''

# i.  for

for a in range(1,10):
     

     if a % 3 == 0:
               #break # to terminate the iteration
               continue  # skip the current cycle 

     print(a,end=',')     
          

#print table of two
for d in range(2,21,2):
     print(d)
     

#print in reverse
for a in range(5,0,-1):
     print(a)



#ii. while
i =1
while i<10:
     print(i)

     i=i+1
     

#print table of 5
i = 5 #init 
while i<51:  #condition 
     print(i)
     i = i+5 # incrementer 
     

#print in reverse
i = 5
while i>0:
     print(i)
     i=i-1





     


     

     

