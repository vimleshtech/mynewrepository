name = input('enter name :')

print('count of chars :',len(name))
print(' :',name.upper())
print(' :',name.lower())

##slicer: raman sinha
print(name[1:3])

print(name[:3])
print(name[4:])

##split # raman kumar sinha 
col = name.split(' ')  # ['raman','kumar','sinha']

print(col)



