#key:value 
words ={'a':'alpha','2':'two','b':'beta'        }

w = input('enter key to be searc :')
print(words[w])

