def wel():
    print('welcome to fun world..')

def add(a,b):
    c = a+b
    print(c)
    
def sub(a,b):
    c = a+b
    return c
    
'''
print('hi')
wel()
wel()
add(11,2)
a = sub(22,3)
print(a)
'''



    
