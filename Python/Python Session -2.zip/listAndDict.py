# list : is known as array
#list : is collection of data or values, multiple values can be stored on single variable

#a = [11,2,2,32,1212,'dddffd','ddd']
a = [11,2,2,32,1212,1,2]
print(a)
print(type(a))  # show data type 

#access by index

print(a[3]) # print 4th element 

print(len(a))   # print size of list 
print(max(a)) #show highest value
print(min(a)) # show  lowest value 
print(sum(a))  # show total

a.sort()        #sort the list 
print(a)

#push /add new element in existing list 
a.append(11222)
a.append(3333)
print(len(a))
print(a)

#remove existing element/value 
a.remove(1)
print(len(a))
print(a)

#replace/insert data on existing insert 
a.insert(3,100)
print(a[3])

 
##traverse the list element
for i in range(0,len(a)):
    print(a[i])
    

##print in reverse order 
for i in range(len(a)-1,-1,-1):
    print(a[i])
    
## for each or advance loop
for d in a:  # forward only 
    print(d)
    
###### input data from user and add to list
emp = [] #declare empty list

s = int(input('size of array :'))

for i in range(0,s):
    name = input('enter name :')
    emp.append(name)


print(emp)

              
############## two dimenssion list / multiple dimenssion
d = [[1,2,23],[3,4,5]]

print(d)
print(d[1])
print(d[1][2])



for r in d: 
    for c in r:
        print(c,end=' ')
    print()
        







    










