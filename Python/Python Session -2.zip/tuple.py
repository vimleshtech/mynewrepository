
days = ('mon','tue','wed','thu','friday')

print(days)
#days[1]= 'ddd'

d = input('enter day name :')

if d in days:
    print('exist')
else:
    print('not exists')
    

