
sid = input('enter id  ')
name = input('enter name ')
hs = input('enter hs ')
es = input('enter es ')
cs = input('enter cs ')
ms = input('enter ms ')


total =  int(hs)+ int(es)+ int(cs)+ int(ms)

print('total score :',total)


avg = total/4
print('total score :',avg)


if avg > 80:
     print('A')
elif avg>70:
     print('B')
elif avg>60:
     print('C')
else:
     print('D')
     



