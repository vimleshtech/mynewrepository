sals = []

'''
s = int(input('enter size of array :'))
for i in range(0,s):
     d = input('enteter data :')
     sals.append(d)
'''

c ='y'


while  c =='y':

     c = input('press 1 for add new element , 0 for exit ')

     if c == '1':
          d = input('enteter data :')
          sals.append(d)
          c ='y'
     elif c =='0':
         print('you have choosen exit ...')
     else:
          print('invalid choice')
          c ='y'
          
          
          

print(sals)

