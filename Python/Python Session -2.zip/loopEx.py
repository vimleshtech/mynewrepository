# for loop : 

for i in range(1,5): # from 1 to 4 , default incrementer is 1
    print(i) 

print('.....')
#print in reverse
    
for i in range(5,0,-1): # from 5 to 1
    print(i,end=' ')


print()
#break : to terminate the iteration / loop 
for i in range(1,10):
    if i %4 == 0:
        break

    print(i)


#continue : to skip current iteration 
for i in range(1,10):
    if i %4 == 0:
        continue

    print(i)

# print table to 3
for t in range(3,31,3):
    print(t)


# print table to 2
for t in range(1,11):
    print(t,' * 2 = ', (t*2))


############### while
i =1
while i<3:
    print(i)
    i = i+1

## nested loop # nested loop
for r  in range(0,3):   # 0 1 2  # rows
    for c in range(0,3): # 0 1 2 # cols
        print(c,end=' ')            # 0 1 2 0 1 2 0 1 2
        
    print()
          




        
        
            
        

    



