'''
import function

function.add(33,34)
'''

'''
import function as f

f.add(11,2)
f.wel()
'''
from function import wel,add
wel()
add(11,2)













