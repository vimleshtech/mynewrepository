emp=[[11,'jaitn',23],[22,'rahul',34],[30,'raman',31]]

print(emp)

print(emp[1])

print(emp[1][0])


for r in emp:
     print(r)
     


for r in emp:
     for c in r:
          print(c,end=' ')
     print()
     
