a = [11,22,122121,1]

print(a)

print(a[2])
print(len(a))

'''
for i in range(0,len(a)):
     print(a[i])
     
'''
#print list in reverse order
for i in range(len(a)-1,-1,-1):
     print(a[i])


for e in a: # forward only 
     print(e)

print(sum(a))
print(max(a))
print(min(a))

a.sort()
print(a)

a.remove(22)
print(a)



a.append(1000)
print(a)


a.insert(1,1000)
print(a)


a.remove(a[2])

print(a)


for i in range(0,len(a)):
     if a[i]== 1000:
          a[i] = 2000
          print(i)

print(a)


          























