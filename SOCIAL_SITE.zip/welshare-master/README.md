Welshare
--------

Welshare was a social network aggregator and a tool for power users, with a lot of useful feature (at http://welshare.com)

It has been abandoned as a running project, but pieces of the source code and ideas from it can be used for similar project (and not only). The integration with social networks is mostly outdated, so the project is not immediately functional.

The project is written in Java, using Spring-MVC, spring, hibernate.MySQL and Neo4j are used as data stores. 
