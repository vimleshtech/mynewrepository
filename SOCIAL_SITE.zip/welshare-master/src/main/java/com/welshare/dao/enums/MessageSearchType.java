package com.welshare.dao.enums;

public enum MessageSearchType {
    ALL, STREAM, OWN;
}
