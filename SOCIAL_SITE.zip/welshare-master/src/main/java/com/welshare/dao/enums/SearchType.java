package com.welshare.dao.enums;

public enum SearchType {

    START, FUZZY, FULL
}
