package com.welshare.service.exception;

public class OperationUnsuccessfulException extends RuntimeException {

    public OperationUnsuccessfulException(String message) {
        super(message);
    }
}
