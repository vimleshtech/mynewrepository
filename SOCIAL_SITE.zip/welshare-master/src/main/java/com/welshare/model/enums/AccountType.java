package com.welshare.model.enums;

public enum AccountType {
    FREE, PAID
}
