package com.welshare.service;

import org.junit.Ignore;

import com.welshare.test.BaseSpringTest;

@Ignore
public class MessageServiceTest extends BaseSpringTest {


}
