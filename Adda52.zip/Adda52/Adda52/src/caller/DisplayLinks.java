//=======================================================================================
// --- Created By: Rahul Shrivastava
// --- Created Date: 
// --- Modified Date: 
// --- Modified By: 
//=======================================================================================

package caller;
import org.openqa.selenium.WebDriver;


public class DisplayLinks {
	 	static WebDriver driver;
	    static String baseUrl;
	/*public static void main (String[] args) throws InterruptedException 
	  {
		driver = new FirefoxDriver();
	    baseUrl = "http://adda52.org/";
	    driver.get(baseUrl + "/");
	  try {
	    List<WebElement> no = driver.findElements(By.tagName("a"));
	    int nooflinks = no.size(); 
	    System.out.println(nooflinks);
	    for (WebElement pagelink : no)
	         {
	          String linktext = pagelink.getText();
	          String link = pagelink.getAttribute("href"); 
	          System.out.println(linktext+" ->");
	          System.out.println(link);
	          }
	   }catch (Exception e){
	             System.out.println("error "+e);
	         }
	           driver.quit();
	  }*/
}
