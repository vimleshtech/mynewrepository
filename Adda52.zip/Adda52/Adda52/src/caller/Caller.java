//=======================================================================================
// --- Created By: Rahul Shrivastava
// --- Created Date: 
// --- Modified Date: 
// --- Modified By: 
//=======================================================================================

package caller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import testcases.BuyRealChips;
import testcases.MyAccount;
import utilities.Common;
import utilities.ConfigUtility;
import utilities.ExcelUtility;

public class Caller {

	static {
		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream("project.properties"));
			ConfigUtility.setConfigProperties(properties);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws IOException {
		// public void main() throws IOException {

		Common common = new Common();
		common.setTestInput();

		ExcelUtility excelUtil = new ExcelUtility();

		Result result = JUnitCore.runClasses(MyAccount.class);

		HashMap<String, String> testResultMap = new HashMap<String, String>();
		ArrayList<Class> classList = new ArrayList<Class>();

		// classList.add(HomePage.class);
		// classList.add(SignUp.class);
		// /classList.add(MyAccount.class);
		classList.add(BuyRealChips.class);
		// classList.add(RedeemChips.class);

		// Put all test Case with blank value in Map
		for (Class myClass : classList) {
			testResultMap = new HashMap<String, String>();
			System.out.println("Class Name" + myClass.getName());
			if (myClass.getName().equals("testcases.HomePage")) {
				System.out.println("home");
				utilities.ExcelUtility.GlobalSheetIndex = 0;
			} else if (myClass.getName().equals("testcases.SignUp")) {
				System.out.println("signup");
				utilities.ExcelUtility.GlobalSheetIndex = 1;
			} else if (myClass.getName().equals("testcases.MyAccount")) {
				utilities.ExcelUtility.GlobalSheetIndex = 3;
			} else if (myClass.getName().equals("testcases.BuyRealChips")) {
				utilities.ExcelUtility.GlobalSheetIndex = 4;
			} else if (myClass.getName().equals("testcases.RedeemChips")) {
				utilities.ExcelUtility.GlobalSheetIndex = 5;
			}

			// Read all the testCase from excel and store their row index in
			// Map.
			excelUtil.readExcelTestCases("My.xls");

			Method[] methodList = myClass.getMethods();
			for (Method method : methodList) {
				String methodKey = method.getName().substring(4);
				testResultMap.put(methodKey, "");
			}

			Set keySet = testResultMap.keySet();
			Iterator itr = keySet.iterator();

			// Pushing fail Result

			for (Failure failure : result.getFailures()) {
				while (itr.hasNext()) {
					String key = (String) itr.next();
					if (failure.getTestHeader().contains(key)) {
						System.out.println("Fail Key:::" + key);
						testResultMap.put(key, "FAIL");
						break;
					}
				}
				System.out.println(failure.getTestHeader() + "------"
						+ failure.toString());

			}

			itr = keySet.iterator();

			// Pushing pass Result

			while (itr.hasNext()) {
				String key = (String) itr.next();
				if (testResultMap.get(key).equals("")) {
					System.out.println("Pass Key:::" + key);
					testResultMap.put(key, "PASS");

				}
			}

			// if (!common.getInnerResultMap().isEmpty()) {
			// testResultMap.putAll(common.getInnerResultMap());
			// }

			itr = keySet.iterator();

			Iterator<Entry<String, String>> commonItr = common
					.getInnerResultMap().entrySet().iterator();
			while (commonItr.hasNext()) {
				Entry entry = commonItr.next();
				// String value = commonItr.next().getValue();

				System.out.println("KEY***" + entry.getKey());
				System.out.println("VALUE***" + entry.getValue());
			}

			/*
			 * to-do
			 * 
			 * Delete all the methods from testResultMap, which are the part of
			 * java.lang.Object or Junit API.
			 */

			// Printing Test Case with their Result
			// while (itr.hasNext()) {
			// String key = (String) itr.next();
			// System.out.println(key + "--------------------"
			// + testResultMap.get(key));
			// }

			// Write the TestCase Result in Excel

			excelUtil.writeExcelTestResult(testResultMap);
		}
	}
}

/*
 * SignUp obj2 = new SignUp();
 * 
 * try{ obj2.setUp(); obj2.test001(); } catch (Exception e){
 * e.printStackTrace(); }
 */
// utilities.common o = new utilities.common();
// o.saveReportInExce();
/*
 * MyAccount obj2 = new MyAccount(); try{ obj2.setUp();
 * obj2.testTC0176_TC0183(); } catch (Exception e){ e.printStackTrace(); }
 */
/*
 * SignUp obj1 = new SignUp(); try { obj1.setUp(); obj1.testTC0110(); } catch
 * (Exception e){ e.printStackTrace(); }
 */

// DBConnectivity DBCon = new DBConnectivity();
// DBCon.postdata();
// DBCon.getdata();