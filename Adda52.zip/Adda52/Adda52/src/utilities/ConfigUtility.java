//=======================================================================================
// --- Created By: Rahul Shrivastava
// --- Created Date: 
// --- Modified Date: 
// --- Modified By: 
//=======================================================================================

package utilities;

import java.util.Properties;

public class ConfigUtility {

	private static Properties configProperties = new Properties();

	public static Properties getConfigProperties() {
		return configProperties;
	}

	public static void setConfigProperties(Properties configProperties) {
		ConfigUtility.configProperties = configProperties;
	}

	public static String getProperty(String key) {
		return configProperties.getProperty(key);
	}

}
