//=======================================================================================
// --- Created By: Rahul Shrivastava
// --- Created Date: 
// --- Modified Date: 
// --- Modified By: 
//=======================================================================================

package utilities;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class BrowserStartup {

	  protected static WebDriver driver;
	  protected static String baseUrl;
	  protected static boolean acceptNextAlert = true;
	  protected static StringBuffer verificationErrors = new StringBuffer();
	  
	  public static int attemptCounter = 0;
	  protected  String targetBrowser = "IE";
	
	  
	  
}
