package testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class PopUps {
	 private WebDriver driver;
	  private String baseUrl;
	  private boolean acceptNextAlert = true;
	  private StringBuffer verificationErrors = new StringBuffer();

	  @Before
	  public void setUp() throws Exception {
		
		System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.Jdk14Logger");
		Logger.getAnonymousLogger().getParent().setLevel(Level.WARNING);  
		  
	    driver = new FirefoxDriver();
	    baseUrl = "http://adda52.org/";
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  }

// Forgot Password
	  @Test
	  public void testForgotPassword() throws Exception {
	    driver.get(baseUrl + "/");
	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("Adda52.com")).click();
	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    try {
	      assertTrue(isElementPresent(By.linkText("Forgot Password")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.linkText("Forgot Password")).click();
	    
	    String myWindowHandle = driver.getWindowHandle();
	    driver.switchTo().window(myWindowHandle);
	    
	    try {
	        assertTrue(isElementPresent(By.xpath("//*[@id='tinycontent']/div[2]")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      try {
	        assertTrue(isElementPresent(By.xpath("//*[@id='login-box']/div[2]")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      try {
	        assertTrue(isElementPresent(By.xpath("//*[@id='login-box']/div[3]")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      try {
	        assertTrue(isElementPresent(By.id("emailFP")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      try {
	        assertTrue(isElementPresent(By.id("submit_fp")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      try {
	        assertTrue(isElementPresent(By.id("Forgot2")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      driver.findElement(By.id("emailFP")).click();
	      driver.findElement(By.id("emailFP")).clear();
	      driver.findElement(By.id("emailFP")).sendKeys("testingemail");
	      driver.findElement(By.id("submit_fp")).click();
	      try {
	        assertTrue(isElementPresent(By.id("pwd_warnFP")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      driver.findElement(By.id("emailFP")).click();
	      driver.findElement(By.id("emailFP")).clear();
	      driver.findElement(By.id("emailFP")).sendKeys("testing@@asasfsfd");
	      driver.findElement(By.id("submit_fp")).click();
	      try {
	        assertTrue(isElementPresent(By.id("pwd_warnFP")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      driver.findElement(By.id("emailFP")).clear();
	      driver.findElement(By.id("emailFP")).sendKeys("!@#$!@#@!");
	      driver.findElement(By.id("submit_fp")).click();
	      try {
	        assertTrue(isElementPresent(By.id("pwd_warnFP")));
	      } catch (Error e) {
	        verificationErrors.append(e.toString());
	      }
	      driver.findElement(By.id("emailFP")).click();
	      driver.findElement(By.id("emailFP")).clear();
	      driver.findElement(By.id("emailFP")).sendKeys("test@test.com");
	      driver.findElement(By.id("submit_fp")).click();
      
	      driver.findElement(By.xpath("//*[@id='tinycontent']/div[1]/div/a"));
	    }
	  	  	
// My Account > Account Summary > View Ticket Summary
	  @Test
	  public void testViewTicketSummary() throws Exception {
	    driver.get(baseUrl + "/");
//	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("Adda52.com")).click();
	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.id("username")).clear();
	    driver.findElement(By.id("username")).sendKeys("rahulsh");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("gauss123");
	    driver.findElement(By.id("btn-login")).click();
	    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("My Account")).click();
	    assertEquals("Adda52.com", driver.getTitle());
	    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[3]/a/span")).click();
	    assertEquals("Adda52.com", driver.getTitle());
	    driver.findElement(By.id("ticket-summary")).click();
	    
	    String myWindowHandle = driver.getWindowHandle();
	    driver.switchTo().window(myWindowHandle);
	    
	    driver.findElement(By.id("tinybox")).click();
	    try {
	      assertTrue(isElementPresent(By.id("tinybox")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='tinycontent']/div[1]")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='tinycontent']/div[2]/table/tbody/tr[1]/td[1]")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='tinycontent']/div[2]/table/tbody/tr[1]/td[2]")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='tinycontent']/div[2]/table/tbody/tr[1]/td[3]")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    try {
	      assertTrue(isElementPresent(By.xpath("//*[@id='tinycontent']/div[2]/table/tbody/tr[1]/td[4]")));
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.linkText("X")).click();
	  }
	  
	 
	  
	  @After
	  public void tearDown() throws Exception {
	    driver.quit();
	    String verificationErrorString = verificationErrors.toString();
	    if (!"".equals(verificationErrorString)) {
	      fail(verificationErrorString);
	    }
	  }

	  private boolean isElementPresent(By by) {
	    try {
	      driver.findElement(by);
	      return true;
	    } catch (NoSuchElementException e) {
	      return false;
	    }
	  }

	  private boolean isAlertPresent() {
	    try {
	      driver.switchTo().alert();
	      return true;
	    } catch (NoAlertPresentException e) {
	      return false;
	    }
	  }

	  private String closeAlertAndGetItsText() {
	    try {
	      Alert alert = driver.switchTo().alert();
	      String alertText = alert.getText();
	      if (acceptNextAlert) {
	        alert.accept();
	      } else {
	        alert.dismiss();
	      }
	      return alertText;
	    } finally {
	      acceptNextAlert = true;
	    }
	  }
}
