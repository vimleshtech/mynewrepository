//=======================================================================================
// --- Created By: Rahul Shrivastava
// --- Created Date: 16-06-2014
// --- Modified Date: 
// --- Modified By: 
//=======================================================================================

package testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import utilities.BrowserStartup;
import utilities.Common;

public class RedeemChips extends BrowserStartup {
	
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  private Map<String, String> innerResultMap = null;
  private Common common = new Common();

  @Before
  public void RedeemChips() throws Exception {
	  		
	  	driver = new FirefoxDriver();
		baseUrl = "http://adda52.com/";

		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.get(baseUrl + "/");
		driver.findElement(By.id("username")).click();
		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("username")).sendKeys(Common.test_user);
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys(Common.test_password);
		driver.findElement(By.id("btn-login")).click();
}

  @Test
  public void testTC0538() throws Exception {
	driver.navigate().to(baseUrl + "/");
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
    try {
      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/div")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertTrue(isElementPresent(By.xpath("//*[@id='wrapper']/section/div/article/h2")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertTrue(isElementPresent(By.xpath("//*[@id='updateRedeemProfile']/div[1]/b")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertTrue(isElementPresent(By.xpath("//*[@id='updateRedeemProfile']/div[2]/label/b")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertTrue(isElementPresent(By.xpath("//*[@id='firstname']")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertTrue(isElementPresent(By.xpath("//*[@id='updateRedeemProfile']/div[3]/label/b")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertTrue(isElementPresent(By.xpath("//*[@id='lastname']")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertTrue(isElementPresent(By.xpath("//*[@id='updateRedeemProfile']/div[4]/label/b")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertTrue(isElementPresent(By.xpath("//*[@id='testclick1']")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    try {
      assertTrue(isElementPresent(By.xpath("//*[@id='btn-continue']")));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }


  @Test
  public void testTC0540() throws Exception {
	driver.navigate().to(baseUrl + "/");
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("testing@");
    driver.findElement(By.id("btn-continue")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("testing#");
    driver.findElement(By.id("btn-continue")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("testing*");
    driver.findElement(By.id("btn-continue")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("testing$");
    driver.findElement(By.id("btn-continue")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("@#*$@#$*");
    driver.findElement(By.id("btn-continue")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }


  @Test
  public void testTC0541() throws Exception {
	driver.navigate().to(baseUrl + "/");
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("testing");
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("@#$*testing");
    driver.findElement(By.id("btn-continue")).click();
    
    if(driver.findElement(By.xpath("//*[@id='my_fname']")).getText().equals("The First Name may only contain alphabetical characters."))
    {
    	System.out.println("Test Case Has Passed");
    }
    else{
    	System.out.println("Test Case Has Failed	");
    }
    	
    	
  }

  @Test
  public void testTC0542() throws Exception {
	driver.navigate().to(baseUrl + "/");
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("@#$*12345");
    driver.findElement(By.id("btn-continue")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("12345@#$*");
    driver.findElement(By.id("btn-continue")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }


  @Test
  public void testTC0543() throws Exception {
	driver.navigate().to(baseUrl + "/");
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("rahul12345");
    driver.findElement(By.id("btn-continue")).click();
    try {
      assertEquals("The First Name may only contain alphabetical characters.", driver.findElement(By.id("my_fname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("12345testing");
    driver.findElement(By.id("btn-continue")).click();
    
    if(driver.findElement(By.xpath("//*[@id='my_fname']")).getText().equals("The First Name may only contain alphabetical characters."))
    {
    	System.out.println("Test Case Has Passed");
    }
    else
    {
    	System.out.println("Test Case Has Failed");
    }
    
  }


  @Test
  public void testTC0544() throws Exception {
	driver.navigate().to(baseUrl + "/");
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
    driver.findElement(By.id("firstname")).clear();
    driver.findElement(By.id("firstname")).sendKeys("qawsedrftgyhujikolpqa");
    driver.findElement(By.id("btn-continue")).click();
    try {
      assertEquals("The First Name should not exceed 20 characters in length.", driver.findElement(By.id("my_fname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }


  @Test
  public void testTC0546() throws Exception {
	driver.navigate().to(baseUrl + "/");
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
    driver.findElement(By.id("lastname")).clear();
    driver.findElement(By.id("lastname")).sendKeys("@#$*");
    driver.findElement(By.id("btn-continue")).click();
    driver.findElement(By.id("my_lname")).click();
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname")).clear();
    driver.findElement(By.id("lastname")).sendKeys("#$@*");
    driver.findElement(By.id("btn-continue")).click();
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }


  @Test
  public void testTC0547() throws Exception {
	driver.navigate().to(baseUrl + "/");
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
    driver.findElement(By.id("lastname")).clear();
    driver.findElement(By.id("lastname")).sendKeys("@#$*test");
    driver.findElement(By.id("btn-continue")).click();
    
    if(driver.findElement(By.xpath("//*[@id='my_lname']")).getText().equals("The Last Name may only contain alphabetical characters."))
    {
    	System.out.println("Test Case Has Passed");
    }
    else
    {
    	System.out.println("Test Case Has Failed");
    }
  }


  @Test
  public void testTC0548() throws Exception {
	driver.navigate().to(baseUrl + "/");
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
    driver.findElement(By.id("lastname")).clear();
    driver.findElement(By.id("lastname")).sendKeys("@#$*&12345");
    driver.findElement(By.id("btn-continue")).click();
    driver.findElement(By.id("my_lname")).click();
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname")).clear();
    driver.findElement(By.id("lastname")).sendKeys("12345@#$*");
    driver.findElement(By.id("btn-continue")).click();
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }


  @Test
  public void testTC0549() throws Exception {
	driver.navigate().to(baseUrl + "/");
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
    driver.findElement(By.id("lastname")).clear();
    driver.findElement(By.id("lastname")).sendKeys("test12345");
    driver.findElement(By.id("btn-continue")).click();
    try {
      assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("lastname")).clear();
    driver.findElement(By.id("lastname")).sendKeys("12345test");
    driver.findElement(By.id("btn-continue")).click();
    
    if(driver.findElement(By.xpath("//*[@id='my_lname']")).getText().equals("The Last Name may only contain alphabetical characters."))
    {
    	System.out.println("Test Case Has Passed");
    }
    else
    {
    	System.out.println("Test Case Has Failed");
    }
  }


  @Test
  public void testTC0550() throws Exception {
	driver.navigate().to(baseUrl + "/");
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
    driver.findElement(By.id("lastname")).clear();
    driver.findElement(By.id("lastname")).sendKeys("qawsedrftgyhujikolpqa");
    driver.findElement(By.id("btn-continue")).click();
    try {
      assertEquals("The Last Name should not exceed 20 characters in length.", driver.findElement(By.id("my_lname")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }


  @Test
  public void testTC0552_TC0555() throws Exception {
	innerResultMap = new HashMap<String, String>();
    driver.get(baseUrl + "/");
    driver.findElement(By.xpath("html/body/div[1]/div/div/img")).click();
    
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("rahulshri");
    driver.findElement(By.id("password")).sendKeys("gauss123");
    driver.findElement(By.id("btn-login")).click();
    
    driver.findElement(By.linkText("My Account")).click();
    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
    driver.findElement(By.xpath("//*[@id='testclick1']")).click();
    
    String myWindowHandle = driver.getWindowHandle();
    driver.switchTo().window(myWindowHandle);
    // For Symbol Values
    driver.findElement(By.xpath("//*[@id='tinycontent']/div[2]"));
    driver.findElement(By.xpath("//*[@id='mobile']")).sendKeys("@#$*&");
    driver.findElement(By.xpath("//*[@id='btn-save']")).click();
    
    if(driver.findElement(By.xpath("//*[@id='mobile_err']")).getText().isEmpty())
    {

		innerResultMap.put("TC0552", "PASS");

	} else {
		innerResultMap.put("TC0552", "FAIL");
	}
    
    // For Alpha Values
    driver.findElement(By.xpath("//*[@id='tinycontent']/div[2]"));
    driver.findElement(By.xpath("//*[@id='mobile']")).sendKeys("asdfghqw");
    driver.findElement(By.xpath("//*[@id='btn-save']")).click();
    
    if(driver.findElement(By.xpath("//*[@id='mobile_err']")).getText().isEmpty())
    {

		innerResultMap.put("TC0553", "PASS");

	} else {
		innerResultMap.put("TC0553", "FAIL");
	}
    
    // For numeric values less then 10
    driver.findElement(By.xpath("//*[@id='tinycontent']/div[2]"));
    driver.findElement(By.xpath("//*[@id='mobile']")).sendKeys("852706164");
    driver.findElement(By.xpath("//*[@id='btn-save']")).click();
    
    if(driver.findElement(By.xpath("//*[@id='mobile_err']")).getText().isEmpty())
    {

		innerResultMap.put("TC0554", "PASS");

	} else {
		innerResultMap.put("TC0554", "FAIL");
	}
  
    // For numeric values greater then 10
    driver.findElement(By.xpath("//*[@id='tinycontent']/div[2]"));
    driver.findElement(By.xpath("//*[@id='mobile']")).sendKeys("56489745617");
    driver.findElement(By.xpath("//*[@id='btn-save']")).click();
    
    if(driver.findElement(By.xpath("//*[@id='mobile_err']")).getText().isEmpty())
    {

		innerResultMap.put("TC0555", "PASS");

	} else {
		innerResultMap.put("TC0555", "FAIL");
	}
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
