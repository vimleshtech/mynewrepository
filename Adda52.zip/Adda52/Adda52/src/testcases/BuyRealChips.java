//=======================================================================================
// --- Created By: Rahul Shrivastava
// --- Created Date: 
// --- Modified Date: 
// --- Modified By: 
//=======================================================================================

package testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import utilities.BrowserStartup;
import utilities.Common;

public class BuyRealChips extends BrowserStartup {

	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	private Map<String, String> innerResultMap = null;
	private Common common = new Common();

	@Before
	public void setUp() throws Exception {

		driver = new FirefoxDriver();
		baseUrl = "http://adda52.com/";

		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.get(baseUrl + "/");
		driver.findElement(By.id("username")).click();
		driver.findElement(By.id("username")).clear();
		driver.findElement(By.id("username")).sendKeys(Common.test_user);
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys(Common.test_password);
		driver.findElement(By.id("btn-login")).click();
	}

	@Test
	public void testTC0343() throws Exception {
		driver.navigate().to(baseUrl + "/");
		driver.findElement(By.linkText("My Account")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=_e_0IcL | ]]
		try {
			assertTrue(isElementPresent(By.id("credit-card")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=_e_0IcL | ]]
		try {
			assertTrue(isElementPresent(By.id("debit-card")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=_e_0IcL | ]]
		try {
			assertTrue(isElementPresent(By.id("net-banking")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=_e_0IcL | ]]
		try {
			assertTrue(isElementPresent(By.id("cod")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=_e_0IcL | ]]
		try {
			assertTrue(isElementPresent(By.id("scratch")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=fbMainContainer | ]]
		// driver.findElement(By.id("fbInspectButton")).click();
		// ERROR: Caught exception [ERROR: Unsupported command [selectWindow |
		// name=_e_0IcL | ]]
		try {
			assertTrue(isElementPresent(By
					.xpath("//div[@id='wrapper']/section/div/article")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}
	

	@Test
	public void testTC0346() throws Exception {
		driver.navigate().to(baseUrl + "/");
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("li.active > a > span")).click();
		driver.findElement(By.id("credit-card")).click();
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("The First Name field is required.", driver
					.findElement(By.id("my_fname_1")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("The Last Name field is required.", driver
					.findElement(By.id("my_lname_1")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("Enter a valid mobile no.",
					driver.findElement(By.id("my_mob_1")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	@Test
	public void testTC0347TC0351() throws Exception {
		innerResultMap = new HashMap<String, String>();
		driver.navigate().to(baseUrl + "/");
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("li.active > a > span")).click();
		driver.findElement(By.id("credit-card")).click();
		driver.findElement(By.id("firstname_5")).clear();
		driver.findElement(By.id("firstname_5")).sendKeys("rahul@");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_5")).getText());
			if (driver.findElement(By.id("my_fname_5")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0347", "PASS");

			} else {
				innerResultMap.put("TC0347", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_5")).clear();
		driver.findElement(By.id("firstname_5")).sendKeys("rahul#");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_5")).getText());
			if (driver.findElement(By.id("my_fname_5")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0348", "PASS");

			} else {
				innerResultMap.put("TC0348", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_5")).clear();
		driver.findElement(By.id("firstname_5")).sendKeys("123457848");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_5")).getText());
			if (driver.findElement(By.id("my_fname_5")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0349", "PASS");

			} else {
				innerResultMap.put("TC0349", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_5")).clear();
		driver.findElement(By.id("firstname_5")).sendKeys("rahul1548");
		driver.findElement(By.cssSelector("p > a > img")).click();
		driver.findElement(By.id("credit-card")).click();
		driver.findElement(By.id("firstname_5")).clear();
		driver.findElement(By.id("firstname_5")).sendKeys("r8748#");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_5")).getText());

			if (driver.findElement(By.id("my_fname_5")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0350", "PASS");

			} else {
				innerResultMap.put("TC0350", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_5")).clear();
		driver.findElement(By.id("firstname_5")).sendKeys("qawsedrftgyhujikolpqa");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("The First Name should not exceed 20 characters in length.",driver.findElement(By.id("my_fname_5")).getText());

			if (driver.findElement(By.id("my_fname_5")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0351", "PASS");

			} else {
				innerResultMap.put("TC0351", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

	@Test
	public void testTC0353TC0357() throws Exception {
		innerResultMap = new HashMap<String, String>();
		driver.navigate().to(baseUrl + "/");

		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("li.active > a > span")).click();
		driver.findElement(By.id("credit-card")).click();
		driver.findElement(By.id("lastname_5")).click();
		driver.findElement(By.id("lastname_5")).clear();
		driver.findElement(By.id("lastname_5")).sendKeys("rahul@@");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_5")).getText());
			if(driver.findElement(By.id("my_lname_5")).getText().equals("The Last Name may only contain alphabetical characters."))
					{				
				innerResultMap.put("TC0353", "PASS");

		} else {
			innerResultMap.put("TC0353", "FAIL");
		}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_5")).clear();
		driver.findElement(By.id("lastname_5")).sendKeys("##########");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_5")).getText());
			if(driver.findElement(By.id("my_lname_5")).getText().equals("The Last Name may only contain alphabetical characters.")){
				innerResultMap.put("TC0354", "PASS");
			}
			else{
				innerResultMap.put("TC0354", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_5")).clear();
		driver.findElement(By.id("lastname_5")).sendKeys("@#$ *asdwe");
		driver.findElement(By.cssSelector("p > a > img")).click();
		
		 try {
		 assertEquals("The Last Name may only contain alphabetical characters.", driver.findElement(By.id("my_lname_5")).getText());
			
			if(driver.findElement(By.id("my_lname_5")).getText().equals("The Last Name may only contain alphabetical characters."))
			{
				innerResultMap.put("TC0355", "PASS");
			}
			else{
				innerResultMap.put("TC0355", "FAIL");
			}
		 } 
		 catch (Error e) { verificationErrors.append(e.toString());
		 }
		
		driver.findElement(By.id("lastname_5")).clear();
		driver.findElement(By.id("lastname_5")).sendKeys("5464654#@#$#@$");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_5")).getText());
			if(driver.findElement(By.id("my_lname_5")).getText().equals("The Last Name may only contain alphabetical characters."))
			{
				innerResultMap.put("TC0356", "PASS");
			}
			else{
				innerResultMap.put("TC0356", "FAIL");
			}
			
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_5")).clear();
		driver.findElement(By.id("lastname_5")).sendKeys("rahulshri1234");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_5")).getText());
			
			if(driver.findElement(By.id("my_lname_5")).getText().equals("The Last Name may only contain alphabetical characters."))
			{
				innerResultMap.put("TC0357", "PASS");
			}
			else{
				innerResultMap.put("TC0357", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

	@Test
	public void testTC0359TC0366() throws Exception {
		innerResultMap = new HashMap<String, String>();

		driver.navigate().to(baseUrl + "/");
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("li.active > a > span")).click();
		driver.findElement(By.id("credit-card")).click();
		driver.findElement(By.id("mobile_5")).clear();
		driver.findElement(By.id("mobile_5")).sendKeys("@@@#*##");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_5")).getText());
			
			if(driver.findElement(By.id("my_mob_5")).getText().equals("Enter a valid mobile no."))
			{
				innerResultMap.put("TC0359", "PASS");
			}
			else{
				innerResultMap.put("TC0359", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_5")).clear();
		driver.findElement(By.id("mobile_5")).sendKeys("asdwertfds");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_5")).getText());
			if(driver.findElement(By.id("my_mob_5")).getText().equals("Enter a valid mobile no."))
			{
				innerResultMap.put("TC0360", "PASS");
			}
			else{
				innerResultMap.put("TC0360", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_5")).clear();
		driver.findElement(By.id("mobile_5")).sendKeys("123456789");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_5")).getText());
			if(driver.findElement(By.id("my_mob_5")).getText().equals("Enter a valid mobile no."))
			{
				innerResultMap.put("TC0361", "PASS");
			}
			else{
				innerResultMap.put("TC0361", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_5")).clear();
		driver.findElement(By.id("mobile_5")).sendKeys("12345678912");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_5")).getText());
			if(driver.findElement(By.id("my_mob_5")).getText().equals("Enter a valid mobile no."))
			{
				innerResultMap.put("TC0362", "PASS");
			}
			else{
				innerResultMap.put("TC0362", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_5")).clear();
		driver.findElement(By.id("mobile_5")).sendKeys("@#*$rahul");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_5")).getText());
			if(driver.findElement(By.id("my_mob_5")).getText().equals("Enter a valid mobile no."))
			{
				innerResultMap.put("TC0363", "PASS");
			}
			else{
				innerResultMap.put("TC0363", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_5")).clear();
		driver.findElement(By.id("mobile_5")).sendKeys("12345#$*dr");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_5")).getText());
			if(driver.findElement(By.id("my_mob_5")).getText().equals("Enter a valid mobile no."))
			{
				innerResultMap.put("TC0364", "PASS");
			}
			else{
				innerResultMap.put("TC0364", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}
	
	@Test
	public void testTC0368TC0373() throws Exception {
		innerResultMap = new HashMap<String, String>();
		driver.navigate().to(baseUrl + "/");

		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("li.active > a > span")).click();
		driver.findElement(By.id("debit-card")).click();
		driver.findElement(By.id("firstname_6")).clear();
		driver.findElement(By.id("firstname_6")).sendKeys("@#$&**");
		driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_6")).getText());
			if(driver.findElement(By.id("my_fname_6")).getText().equals("The First Name may only contain alphabetical characters."))
			{
				innerResultMap.put("TC0368", "PASS");
			}
			else{
				innerResultMap.put("TC0368", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_6")).clear();
		driver.findElement(By.id("firstname_6")).sendKeys("@*#rahul");
		driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
		driver.findElement(By.id("firstname_6")).clear();
		driver.findElement(By.id("firstname_6")).sendKeys("@#*&12345");
		driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_6")).getText());
			if(driver.findElement(By.id("my_fname_6")).getText().equals("The First Name may only contain alphabetical characters."))
			{
				innerResultMap.put("TC0369", "PASS");
			}
			else{
				innerResultMap.put("TC0369", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_6")).clear();
		driver.findElement(By.id("firstname_6")).sendKeys("rahul123");
		driver.findElement(By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_6")).getText());
			if(driver.findElement(By.id("my_fname_6")).getText().equals("The First Name may only contain alphabetical characters."))
			{
				innerResultMap.put("TC0370", "PASS");
			}
			else{
				innerResultMap.put("TC0370", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_6")).clear();
		driver.findElement(By.id("firstname_6")).sendKeys("qawsedrftgyhujikolpqa");
		driver.findElement(	By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img")).click();
		try {
			assertEquals("The First Name should not exceed 20 characters in length.",driver.findElement(By.id("my_fname_6")).getText());
			if(driver.findElement(By.id("my_fname_6")).getText().equals("The First Name may only contain alphabetical characters."))
			{
				innerResultMap.put("TC0371", "PASS");
			}
			else{
				innerResultMap.put("TC0371", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

		
	@Test
	public void testTC0374TC0378() throws Exception {
		innerResultMap = new HashMap<String, String>();
		driver.navigate().to(baseUrl + "/");

		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("li.active > a > span")).click();
		driver.findElement(By.id("debit-card")).click();
		driver.findElement(By.id("lastname_6")).click();
		driver.findElement(By.id("lastname_6")).clear();
		driver.findElement(By.id("lastname_6")).sendKeys("@#$%*&");
		driver.findElement(
				By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img"))
				.click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_6")).getText());
			if(driver.findElement(By.id("my_lname_6")).getText().equals("The Last Name may only contain alphabetical characters."))
			{
				innerResultMap.put("TC0374", "PASS");
			}
			else{
				innerResultMap.put("TC0374", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_6")).clear();
		driver.findElement(By.id("lastname_6")).sendKeys("@#$*rahul");
		driver.findElement(
				By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img"))
				.click();
		driver.findElement(By.id("lastname_6")).clear();
		driver.findElement(By.id("lastname_6")).sendKeys("@#*$12345");
		driver.findElement(
				By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img"))
				.click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_6")).getText());
			if(driver.findElement(By.id("my_lname_6")).getText().equals("The Last Name may only contain alphabetical characters."))
			{
				innerResultMap.put("TC0375", "PASS");
			}
			else{
				innerResultMap.put("TC0375", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_6")).clear();
		driver.findElement(By.id("lastname_6")).sendKeys("rahul12345");
		driver.findElement(
				By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img"))
				.click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_6")).getText());
			if(driver.findElement(By.id("my_lname_6")).getText().equals("The Last Name may only contain alphabetical characters."))
			{
				innerResultMap.put("TC0376", "PASS");
			}
			else{
				innerResultMap.put("TC0376", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_6")).clear();
		driver.findElement(By.id("lastname_6")).sendKeys("12345rahul");
		driver.findElement(
				By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img"))
				.click();
		driver.findElement(By.id("lastname_6")).clear();
		driver.findElement(By.id("lastname_6")).sendKeys(
				"qawsedrftgyhujikolpzx");
		driver.findElement(
				By.xpath("//div[@id='debit-card-1']/div[2]/div/p/a/img"))
				.click();
		try {
			assertEquals("The Last Name should not exceed 20 characters in length.",driver.findElement(By.id("my_lname_6")).getText());
			if(driver.findElement(By.id("my_lname_6")).getText().equals("The Last Name should not exceed 20 characters in length."))
			{
				innerResultMap.put("TC0377", "PASS");
			}
			else{
				innerResultMap.put("TC0377", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

	@Test
	public void testTC0385() throws Exception {

		driver.navigate().to(baseUrl + "/");
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("li.active > a > span")).click();
		driver.findElement(By.id("net-banking")).click();
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img")).click();
		try {
			assertEquals("The First Name field is required.", driver.findElement(By.id("my_fname_3")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("The Last Name field is required.", driver.findElement(By.id("my_lname_3")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_3")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	@Test
	public void testTC0386TC0390() throws Exception {
		innerResultMap = new HashMap<String, String>();
		driver.navigate().to(baseUrl + "/");

		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("li.active > a > span")).click();
		driver.findElement(By.id("net-banking")).click();
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("@#$*&");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0386", "PASS");

			} else {
				innerResultMap.put("TC0386", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("@#*&$rahul");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("@#$&*12345");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0387", "PASS");

			} else {
				innerResultMap.put("TC0387", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("rahul12345");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0388", "PASS");

			} else {
				innerResultMap.put("TC0388", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("12345rahul");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys(
				"qazwsxedcrfvtgbyhnujm");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The First Name should not exceed 20 characters in length.",driver.findElement(By.id("my_fname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The First Name should not exceed 20 characters in length.")) {

				innerResultMap.put("TC0389", "PASS");

			} else {
				innerResultMap.put("TC0389", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

	@Test
	public void testTC0392TC0396() throws Exception {
		innerResultMap = new HashMap<String, String>();
		driver.navigate().to(baseUrl + "/");

		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("li.active > a > span")).click();
		driver.findElement(By.id("net-banking")).click();
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The First Name field is required.", driver.findElement(By.id("my_fname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The First Name field is required.")) {

				innerResultMap.put("TC0392", "PASS");

			} else {
				innerResultMap.put("TC0392", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("The Last Name field is required.", driver.findElement(By.id("my_lname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The First Name field is required.")) {

				innerResultMap.put("TC0393", "PASS");

			} else {
				innerResultMap.put("TC0393", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("Enter a valid mobile no.")) {

				innerResultMap.put("TC0394", "PASS");

			} else {
				innerResultMap.put("TC0394", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_3")).clear();
		driver.findElement(By.id("lastname_3")).sendKeys("@#$&*");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The Last Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0395", "PASS");

			} else {
				innerResultMap.put("TC0395", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_3")).clear();
		driver.findElement(By.id("lastname_3")).sendKeys("@#$&*1234");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The Last Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0396", "PASS");

			} else {
				innerResultMap.put("TC0396", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_3")).clear();
		driver.findElement(By.id("lastname_3")).sendKeys("12345@#$*&");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The Last Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0397", "PASS");

			} else {
				innerResultMap.put("TC0397", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_3")).clear();
		driver.findElement(By.id("lastname_3")).sendKeys("rahul12345");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals(
					"The Last Name may only contain alphabetical characters.",
					driver.findElement(By.id("my_lname_3")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_3")).clear();
		driver.findElement(By.id("lastname_3")).sendKeys("12345rahul");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		driver.findElement(By.id("lastname_3")).clear();
		driver.findElement(By.id("lastname_3")).sendKeys(
				"qawsedrftgyhujikolpqa");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals(
					"The Last Name should not exceed 20 characters in length.",
					driver.findElement(By.id("my_lname_3")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

	@Test
	public void testTC0398TC0402() throws Exception {
		innerResultMap = new HashMap<String, String>();
		driver.navigate().to(baseUrl + "/");

		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("li.active > a > span")).click();
		driver.findElement(By.id("net-banking")).click();
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The First Name field is required.", driver.findElement(By.id("my_fname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The First Name field is required.")) {

				innerResultMap.put("TC0398", "PASS");

			} else {
				innerResultMap.put("TC0398", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("The Last Name field is required.", driver.findElement(By.id("my_lname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The Last Name field is required.")) {

				innerResultMap.put("TC0399", "PASS");

			} else {
				innerResultMap.put("TC0399", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_3")).getText());
			if (driver.findElement(By.id("my_mob_3")).getText().equals("Enter a valid mobile no.")) {

				innerResultMap.put("TC0399", "PASS");

			} else {
				innerResultMap.put("TC0399", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_3")).clear();
		driver.findElement(By.id("mobile_3")).sendKeys("@#$&*");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_3")).getText());
			if (driver.findElement(By.id("my_mob_3")).getText().equals("Enter a valid mobile no.")) {

				innerResultMap.put("TC0400", "PASS");

			} else {
				innerResultMap.put("TC0400", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_3")).clear();
		driver.findElement(By.id("mobile_3")).sendKeys("rahulshrivastava");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_3")).getText());
			if (driver.findElement(By.id("my_mob_3")).getText().equals("Enter a valid mobile no.")) {

				innerResultMap.put("TC0401", "PASS");

			} else {
				innerResultMap.put("TC0401", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_3")).clear();
		driver.findElement(By.id("mobile_3")).sendKeys("123456789");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_3")).getText());
			if (driver.findElement(By.id("my_mob_3")).getText().equals("Enter a valid mobile no.")) {

				innerResultMap.put("TC0402", "PASS");

			} else {
				innerResultMap.put("TC0402", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_3")).clear();
		driver.findElement(By.id("mobile_3")).sendKeys("12345678912");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("Enter a valid mobile no.",
					driver.findElement(By.id("my_mob_3")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

	@Test
	public void testTC0403TC0420() throws Exception {
		innerResultMap = new HashMap<String, String>();
		driver.navigate().to(baseUrl + "/");

		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("li.active > a > span")).click();
		driver.findElement(By.id("net-banking")).click();
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The First Name field is required.", driver.findElement(By.id("my_fname_3")).getText());
			if(driver.findElement(By.id("my_fname_3")).getText().equals("The First Name field is required.")){
				innerResultMap.put("TC0403", "PASS");

			} else {
				innerResultMap.put("TC0403", "FAIL");
			}
			
			
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("The Last Name field is required.", driver.findElement(By.id("my_lname_3")).getText());
			if(driver.findElement(By.id("my_lname_3")).getText().equals("The Last Name field is required.")){
				innerResultMap.put("TC0404", "PASS");

			} else {
				innerResultMap.put("TC0404", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_3")).getText());
			if(driver.findElement(By.id("my_mob_3")).getText().equals("Enter a valid mobile no.")){
				innerResultMap.put("TC0405", "PASS");

			} else {
				innerResultMap.put("TC0405", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("@#$&*");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_3")).getText());
			if(driver.findElement(By.id("my_fname_3")).getText().equals("The First Name may only contain alphabetical characters.")){
				innerResultMap.put("TC0406", "PASS");

			} else {
				innerResultMap.put("TC0406", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("#$&*@rahul");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("rahul@#$&*");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_3")).getText());
			if(driver.findElement(By.id("my_fname_3")).getText().equals("The First Name may only contain alphabetical characters."))
			{
				innerResultMap.put("TC0407", "PASS");

			} else {
				innerResultMap.put("TC0407", "FAIL");
			}
			} 
		catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("123456789");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0408", "PASS");

			} else {
				innerResultMap.put("TC0408", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("rahul123");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0409", "PASS");

			} else {
				innerResultMap.put("TC0409", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("123rahul");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("@#$&*1234");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0410", "PASS");

			} else {
				innerResultMap.put("TC0410", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("1234@#$&*");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_3")).getText());
			if (driver.findElement(By.id("my_fname_3")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0411", "PASS");

			} else {
				innerResultMap.put("TC0411", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_3")).clear();
		driver.findElement(By.id("firstname_3")).sendKeys("rahulshr");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		driver.findElement(By.id("lastname_3")).clear();
		driver.findElement(By.id("lastname_3")).sendKeys("@#$&*");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_3")).getText());
			if (driver.findElement(By.id("my_lname_3")).getText().equals("The Last Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0412", "PASS");

			} else {
				innerResultMap.put("TC0412", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_3")).clear();
		driver.findElement(By.id("lastname_3")).sendKeys("@#$&*rahu");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		driver.findElement(By.id("lastname_3")).clear();
		driver.findElement(By.id("lastname_3")).sendKeys("rahu@#$&*");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_3")).getText());
			if (driver.findElement(By.id("my_lname_3")).getText().equals("The Last Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0413", "PASS");

			} else {
				innerResultMap.put("TC0413", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_3")).clear();
		driver.findElement(By.id("lastname_3")).sendKeys("123456");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_3")).getText());
			if (driver.findElement(By.id("my_lname_3")).getText().equals("The Last Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0414", "PASS");

			} else {
				innerResultMap.put("TC0414", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_3")).clear();
		driver.findElement(By.id("lastname_3")).sendKeys("rahul123");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_3")).getText());
			if (driver.findElement(By.id("my_lname_3")).getText().equals("The Last Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0415", "PASS");

			} else {
				innerResultMap.put("TC0415", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_3")).clear();
		driver.findElement(By.id("lastname_3")).sendKeys("123rahul");
		// ERROR: Caught exception [ERROR: Unsupported command [waitForPopUp |
		// PlayNow | 30000]]
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_3")).getText());
			if (driver.findElement(By.id("my_lname_3")).getText().equals("The Last Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0416", "PASS");

			} else {
				innerResultMap.put("TC0416", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_3")).clear();
		driver.findElement(By.id("lastname_3")).sendKeys("shrivas");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		driver.findElement(By.id("mobile_3")).clear();
		driver.findElement(By.id("mobile_3")).sendKeys("@#$&*");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_3")).getText());
			if (driver.findElement(By.id("my_mob_3")).getText().equals("Enter a valid mobile no.")) {

				innerResultMap.put("TC0417", "PASS");

			} else {
				innerResultMap.put("TC0417", "FAIL");
			}
			} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_3")).clear();
		driver.findElement(By.id("mobile_3")).sendKeys("rahul123");
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_3")).getText());
			if (driver.findElement(By.id("my_mob_3")).getText().equals("Enter a valid mobile no.")) {

				innerResultMap.put("TC0418", "PASS");

			} else {
				innerResultMap.put("TC0418", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_3")).clear();
		driver.findElement(By.id("mobile_3")).sendKeys("123rahuls");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_3")).getText());
			if (driver.findElement(By.id("my_mob_3")).getText().equals("Enter a valid mobile no.")) {

				innerResultMap.put("TC0419", "PASS");

			} else {
				innerResultMap.put("TC0419", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_3")).clear();
		driver.findElement(By.id("mobile_3")).sendKeys("1234567");
		driver.findElement(By.cssSelector("#net-banking-1 > div > p > a > img"))
				.click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_3")).getText());
			if (driver.findElement(By.id("my_mob_3")).getText().equals("Enter a valid mobile no.")) {

				innerResultMap.put("TC0420", "PASS");

			} else {
				innerResultMap.put("TC0420", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_3")).clear();
		driver.findElement(By.id("mobile_3")).sendKeys("12345678941");
		try {
			assertEquals("Enter a valid mobile no.",
					driver.findElement(By.id("my_mob_3")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

	@Test
	public void testTC0421TC0423() throws Exception {
		innerResultMap = new HashMap<String, String>();
		driver.navigate().to(baseUrl + "/");

		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("li.active > a > span")).click();
		driver.findElement(By.id("credit-card")).click();
		driver.findElement(By.id("firstname_1")).clear();
		driver.findElement(By.id("firstname_1")).sendKeys("rahultest");
		driver.findElement(By.id("lastname_1")).clear();
		driver.findElement(By.id("lastname_1")).sendKeys("testrahuls");
		driver.findElement(By.id("mobile_1")).clear();
		driver.findElement(By.id("mobile_1")).sendKeys("9898989898");
		driver.findElement(By.cssSelector("p > a > img")).click();
		try {
			assertTrue(isElementPresent(By.xpath("//*[@id='credit-card-1']")));
			if (driver.findElement(By.xpath("//*[@id='credit-card-1']")).isDisplayed()) {

				innerResultMap.put("TC0421", "PASS");

			} else {
				innerResultMap.put("TC0421", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By.xpath("//*[@id='move']/div/div[3]")));
			if (driver.findElement(By.xpath("//*[@id='move']/div/div[3]")).isDisplayed()) {

				innerResultMap.put("TC0422", "PASS");

			} else {
				innerResultMap.put("TC0422", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By.xpath("//*[@id='credit-card-1']/div[2]/div[2]/div[2]/a/img")));
			if (driver.findElement(By.xpath("//*[@id='credit-card-1']/div[2]/div[2]/div[2]/a/img")).isDisplayed()) {

				innerResultMap.put("TC0423", "PASS");

			} else {
				innerResultMap.put("TC0423", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("The First Name field is required.", driver
					.findElement(By.id("my_fname_5")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("The Last Name field is required.", driver
					.findElement(By.id("my_lname_5")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("Enter a valid mobile no.",
					driver.findElement(By.id("my_mob_5")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}

	@Test
	public void testTC0424TC0445() throws Exception {
		innerResultMap = new HashMap<String, String>();
		driver.navigate().to(baseUrl + "/");

		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.cssSelector("li.active > a > span")).click();
		driver.findElement(By.id("credit-card")).click();
		driver.findElement(By.id("firstname_1")).click();
		driver.findElement(By.id("firstname_1")).clear();
		driver.findElement(By.id("firstname_1")).sendKeys("rahultest");
		driver.findElement(By.id("lastname_1")).clear();
		driver.findElement(By.id("lastname_1")).sendKeys("testa");
		driver.findElement(By.id("mobile_1")).clear();
		driver.findElement(By.id("mobile_1")).sendKeys("8989898989");
		driver.findElement(By.cssSelector("p > a > img")).click();
		driver.findElement(By.id("firstname_5")).clear();
		driver.findElement(By.id("firstname_5")).sendKeys("@#$&*");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_5")).getText());
			if (driver.findElement(By.id("my_fname_5")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0424", "PASS");

			} else {
				innerResultMap.put("TC0424", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_5")).clear();
		driver.findElement(By.id("firstname_5")).sendKeys("@#*rtest");
		driver.findElement(By.id("btn-continue")).click();
		driver.findElement(By.id("firstname_5")).clear();
		driver.findElement(By.id("firstname_5")).sendKeys("rtest@#*");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_5")).getText());
			if (driver.findElement(By.id("my_fname_5")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0425", "PASS");

			} else {
				innerResultMap.put("TC0425", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_5")).clear();
		driver.findElement(By.id("firstname_5")).sendKeys("rtest1234");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("The First Name may only contain alphabetical characters.",driver.findElement(By.id("my_fname_5")).getText());
			if (driver.findElement(By.id("my_fname_5")).getText().equals("The First Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0426", "PASS");

			} else {
				innerResultMap.put("TC0426", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_5")).clear();
		driver.findElement(By.id("firstname_5")).sendKeys(
				"qawsedrftgyhujikolpqa");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("The First Name should not exceed 20 characters in length.",driver.findElement(By.id("my_fname_5")).getText());
			if (driver.findElement(By.id("my_fname_5")).getText().equals("The First Name should not exceed 20 characters in length.")) {

				innerResultMap.put("TC0427", "PASS");

			} else {
				innerResultMap.put("TC0427", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("firstname_5")).clear();
		driver.findElement(By.id("firstname_5")).sendKeys("rtesta");
		driver.findElement(By.id("btn-continue")).click();
		driver.findElement(By.id("lastname_5")).clear();
		driver.findElement(By.id("lastname_5")).sendKeys("@#&*");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_5")).getText());
			if (driver.findElement(By.id("my_lname_5")).getText().equals("The Last Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0428", "PASS");

			} else {
				innerResultMap.put("TC0428", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_5")).clear();
		driver.findElement(By.id("lastname_5")).sendKeys("@#&*+rtestb");
		driver.findElement(By.id("btn-continue")).click();
		driver.findElement(By.id("lastname_5")).clear();
		driver.findElement(By.id("lastname_5")).sendKeys("rtestb@#*");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("The Last Name may only contain alphabetical characters.",driver.findElement(By.id("my_lname_5")).getText());
			if (driver.findElement(By.id("my_lname_5")).getText().equals("The Last Name may only contain alphabetical characters.")) {

				innerResultMap.put("TC0429", "PASS");

			} else {
				innerResultMap.put("TC0429", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("lastname_5")).clear();
		driver.findElement(By.id("lastname_5")).sendKeys("testa");
		driver.findElement(By.id("btn-continue")).click();
		driver.findElement(By.id("mobile_5")).clear();
		driver.findElement(By.id("mobile_5")).sendKeys("@#&*");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_5")).getText());
			if (driver.findElement(By.id("my_mob_5")).getText().equals("Enter a valid mobile no.")) {

				innerResultMap.put("TC0430", "PASS");

			} else {
				innerResultMap.put("TC0430", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_5")).clear();
		driver.findElement(By.id("mobile_5")).sendKeys("@#$&*123");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_5")).getText());
			if (driver.findElement(By.id("my_mob_5")).getText().equals("Enter a valid mobile no.")) {

				innerResultMap.put("TC0431", "PASS");

			} else {
				innerResultMap.put("TC0431", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_5")).clear();
		driver.findElement(By.id("mobile_5")).sendKeys("1234567");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_5")).getText());
			if (driver.findElement(By.id("my_mob_5")).getText().equals("Enter a valid mobile no.")) {

				innerResultMap.put("TC0432", "PASS");

			} else {
				innerResultMap.put("TC0432", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_5")).clear();
		driver.findElement(By.id("mobile_5")).sendKeys("1");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("Enter a valid mobile no.",driver.findElement(By.id("my_mob_5")).getText());
			if (driver.findElement(By.id("my_mob_5")).getText().equals("Enter a valid mobile no.")) {

				innerResultMap.put("TC0433", "PASS");

			} else {
				innerResultMap.put("TC0433", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("mobile_5")).clear();
		driver.findElement(By.id("mobile_5")).sendKeys("7897897897");
		driver.findElement(By.id("btn-continue")).click();
		driver.findElement(By.id("address_5")).clear();
		driver.findElement(By.id("address_5")).sendKeys("Delhi6");
		driver.findElement(By.id("btn-continue")).click();
		driver.findElement(By.id("city_5")).clear();
		driver.findElement(By.id("city_5")).sendKeys("789456");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("Enter a valid city name.",driver.findElement(By.id("my_city_5")).getText());
			if (driver.findElement(By.id("my_city_5")).getText().equals("Enter a valid city name.")) {

				innerResultMap.put("TC0434", "PASS");

			} else {
				innerResultMap.put("TC0434", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("city_5")).clear();
		driver.findElement(By.id("city_5")).sendKeys("delhi6");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("Enter a valid city name.",driver.findElement(By.id("my_city_5")).getText());
			if (driver.findElement(By.id("my_city_5")).getText().equals("Enter a valid city name.")) {

				innerResultMap.put("TC0435", "PASS");

			} else {
				innerResultMap.put("TC0435", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("city_5")).clear();
		driver.findElement(By.id("city_5")).sendKeys("delhi");
		driver.findElement(By.id("btn-continue")).click();
		driver.findElement(By.id("pincode_5")).clear();
		driver.findElement(By.id("pincode_5")).sendKeys("@#$&*");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("Enter a valid Pin Code.",
					driver.findElement(By.id("my_pin_5")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("pincode_5")).clear();
		driver.findElement(By.id("pincode_5")).sendKeys("testb");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("Enter a valid Pin Code.",driver.findElement(By.id("my_pin_5")).getText());
			if (driver.findElement(By.id("my_pin_5")).getText().equals("Enter a valid Pin Code.")) {

				innerResultMap.put("TC0436", "PASS");

			} else {
				innerResultMap.put("TC0436", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.id("pincode_5")).clear();
		driver.findElement(By.id("pincode_5")).sendKeys("testb987");
		driver.findElement(By.id("btn-continue")).click();
		driver.findElement(By.id("pincode_5")).clear();
		driver.findElement(By.id("pincode_5")).sendKeys("123456");
		driver.findElement(By.id("btn-continue")).click();
		// new Select(driver.findElement(By.id("state_5")))
		// .selectByVisibleText("DELHI");
		driver.findElement(
				By.xpath("//div[@id='credit-card-1']/div[2]/div[2]/div[2]/a/img"))
				.click();
		driver.findElement(By.id("address_5")).clear();
		driver.findElement(By.id("address_5")).sendKeys("testb");
		driver.findElement(By.id("city_5")).clear();
		driver.findElement(By.id("city_5")).sendKeys("testb");
		driver.findElement(By.id("pincode_5")).clear();
		driver.findElement(By.id("pincode_5")).sendKeys("123455");
		// new Select(driver.findElement(By.id("state_5")))
		// .selectByVisibleText("DELHI");
		driver.findElement(By.id("btn-continue")).click();
		try {
			assertEquals("Card Type",driver.findElement(By.cssSelector("label")).getText());
			if (driver.findElement(By.cssSelector("label")).getText().equals("Card Type")) {

				innerResultMap.put("TC0437", "PASS");

			} else {
				innerResultMap.put("TC0437", "FAIL");
			}
			
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("Amount",driver.findElement(By.cssSelector("#buy_chips_amount > div.formbuychips > label")).getText());
			if (driver.findElement(By.cssSelector("#buy_chips_amount > div.formbuychips > label")).getText().equals("Amount")) {

				innerResultMap.put("TC0438", "PASS");

			} else {
				innerResultMap.put("TC0438", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertEquals("Bonus Code",driver.findElement(By.xpath("//div[@id='buy_chips_amount']/div[3]/label")).getText());
			if (driver.findElement(By.xpath("//div[@id='buy_chips_amount']/div[3]/label")).getText().equals("Bonus Code")) {

				innerResultMap.put("TC0439", "PASS");

			} else {
				innerResultMap.put("TC0439", "FAIL");
			}
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		common.getInnerResultMap().putAll(innerResultMap);
	}
	
// TC0573 - TC0577
	 @Test
	  public void testTC0573TC0577() throws Exception {
		innerResultMap = new HashMap<String, String>();
		driver.navigate().to(baseUrl + "/");

	//    assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("Adda52.com")).click();
	    // assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("My Account")).click();
	    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
	    driver.findElement(By.id("btn-submit")).click();
	    try{	
	    assertEquals("The Amount field is required.", driver.findElement(By.id("redeem_amount_err")).getText());
	    	if(driver.findElement(By.id("redeem_amount_err")).getText().equals("The Amount field is required."))
	    	{
		  	innerResultMap.put("TC0573", "FAIL");	
	    	} else {
	  		innerResultMap.put("TC0573", "FAIL");
	    	}
	  	
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    } 
	    
	    driver.findElement(By.id("amount")).clear();
	    driver.findElement(By.id("amount")).sendKeys("@#$@#test");
	    driver.findElement(By.id("btn-submit")).click();
	    try{
	    	assertEquals("Amount should be an integer.", driver.findElement(By.id("redeem_amount_err")).getText());
	    	if(driver.findElement(By.id("redeem_amount_err")).getText().equals("Amount should be an integer.")){
			  	innerResultMap.put("TC0574", "FAIL");	
	    	} else {
	  		innerResultMap.put("TC0574", "FAIL");
	    	}
	  	
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    } 	
	    	
	    driver.findElement(By.id("amount")).clear();
	    driver.findElement(By.id("amount")).sendKeys("50");
	    driver.findElement(By.id("btn-submit")).click();
	    // assertEquals("Adda52.com", driver.getTitle());
	    try{
	    	assertEquals("Amount should be at least 100.", driver.findElement(By.id("redeem_amount_err")).getText());
	    	if(driver.findElement(By.id("redeem_amount_err")).getText().equals("Amount should be at least 100.")){
			  	innerResultMap.put("TC0575", "FAIL");	
	    	} else {
	  		innerResultMap.put("TC0575", "FAIL");
	    	}
	  	
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    driver.findElement(By.id("amount")).sendKeys("500");
	    driver.findElement(By.id("btn-submit")).click();
	    // assertEquals("Adda52.com", driver.getTitle());
	    driver.findElement(By.id("amount")).clear();
	    driver.findElement(By.id("amount")).sendKeys("5");
	    try{
	    	assertEquals("The Redeem option field is required.", driver.findElement(By.id("redeem_mode_err")).getText());
	    	if(driver.findElement(By.id("redeem_mode_err")).getText().equals("The Redeem option field is required.")){
			  	innerResultMap.put("TC0577", "FAIL");	
	    	} else {
	  		innerResultMap.put("TC0577", "FAIL");
	    	}
	  	
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
		common.getInnerResultMap().putAll(innerResultMap);
	  }
	 
// TC0579 - TC0595
	 @Test
	  public void testTC0579TC0595() throws Exception {
		innerResultMap = new HashMap<String, String>();
		driver.navigate().to(baseUrl + "/");
		
	    //assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("Adda52.com")).click();
	    //assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());

	    //assertEquals("Online Poker India � Play Freeroll and Cash Online Poker & Rummy at Adda52.com", driver.getTitle());
	    driver.findElement(By.linkText("My Account")).click();
	    //assertEquals("Adda52.com", driver.getTitle());
	    driver.findElement(By.xpath("//div[@id='wrapper']/section/div/aside/ul/li[5]/a/span")).click();
	    //assertEquals("Adda52.com", driver.getTitle());
	    driver.findElement(By.id("amount")).clear();
	    driver.findElement(By.id("amount")).sendKeys("5000");
	    driver.findElement(By.id("redeem_mode")).click();
	    try{
	    	assertTrue(isElementPresent(By.xpath("//*[@id='online']/div[1]")));
	    	if(driver.findElement(By.xpath("//*[@id='online']/div[1]")).isDisplayed()){
				innerResultMap.put("TC0579", "PASS");

			} else {
				innerResultMap.put("TC0579", "FAIL");
			}
		  	
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    
	    driver.findElement(By.id("btn-submit")).click();
	    try{
		    assertEquals("Please Select a Bank.", driver.findElement(By.id("bank_name_err")).getText());
		    if(driver.findElement(By.id("bank_name_err")).getText().equals("Please Select a Bank.")){
				innerResultMap.put("TC0580", "PASS");

			} else {
				innerResultMap.put("TC0580", "FAIL");
			}
		  	
	    } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	//    new Select(driver.findElement(By.id("bank_name"))).selectByVisibleText("Allahabad Bank");
	    if(driver.findElement(By.id("bank_name")).isEnabled()){
			innerResultMap.put("TC0581", "PASS");

		} else {
			innerResultMap.put("TC0581", "FAIL");
		}
	    
	    driver.findElement(By.id("btn-submit")).click();
	    try{
	    assertEquals("", driver.findElement(By.id("bank_name_err")).getText());
    	if(driver.findElement(By.id("bank_name_err")).getText().equals("")){
			innerResultMap.put("TC0582", "PASS");

		} else {
			innerResultMap.put("TC0582", "FAIL");
		}
	  	
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
	    driver.findElement(By.id("btn-submit")).click();
	    try{
	    assertEquals("The Branch Name field is required.", driver.findElement(By.id("branch_name_err")).getText());
    	if(driver.findElement(By.id("branch_name_err")).getText().equals("The Branch Name field is required.")){
			innerResultMap.put("TC0583", "PASS");

		} else {
			innerResultMap.put("TC0583", "FAIL");
		}
	  	
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
	    driver.findElement(By.id("branch_name")).clear();
	    driver.findElement(By.id("branch_name")).sendKeys("@#$@#$@#$@#$");
	    driver.findElement(By.id("btn-submit")).click();
	    try{
	    assertEquals("Enter correct values.", driver.findElement(By.id("branch_name_err")).getText());
    	if(driver.findElement(By.id("branch_name_err")).getText().equals("Enter correct values.")){
			innerResultMap.put("TC0584", "PASS");

		} else {
			innerResultMap.put("TC0584", "FAIL");
		}
	  	
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
	    driver.findElement(By.id("branch_name")).clear();
	    driver.findElement(By.id("branch_name")).sendKeys("Gurgaon");
	    driver.findElement(By.id("btn-submit")).click();
	    try{
	    assertEquals("", driver.findElement(By.id("branch_name_err")).getText());
    	if(driver.findElement(By.id("branch_name_err")).getText().equals("")){
			innerResultMap.put("TC0585", "PASS");

		} else {
			innerResultMap.put("TC0585", "FAIL");
		}
	  	
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
	    driver.findElement(By.id("btn-submit")).click();
	    try{
	    assertEquals("The Account Number field is required.", driver.findElement(By.id("account_number_err")).getText());
    	if(driver.findElement(By.id("account_number_err")).getText().equals("The Account Number field is required.")){
			innerResultMap.put("TC0586", "PASS");

		} else {
			innerResultMap.put("TC0586", "FAIL");
		}
	  	
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
	    driver.findElement(By.id("account_number")).clear();
	    driver.findElement(By.id("account_number")).sendKeys("@#$@$@#$@#");
	    driver.findElement(By.id("btn-submit")).click();
	    try{
	    assertEquals("The Account Number should be an integer.", driver.findElement(By.id("account_number_err")).getText());
    	if(driver.findElement(By.id("account_number_err")).getText().equals("The Account Number should be an integer.")){
			innerResultMap.put("TC0587", "PASS");

		} else {
			innerResultMap.put("TC0587", "FAIL");
		}
	  	
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
	    driver.findElement(By.id("account_number")).clear();
	    driver.findElement(By.id("account_number")).sendKeys("testinggauss");
	    driver.findElement(By.id("btn-submit")).click();
	    try{
	    assertEquals("The Account Number should be an integer.", driver.findElement(By.id("account_number_err")).getText());
    	if(driver.findElement(By.id("account_number_err")).getText().equals("The Account Number should be an integer.")){
			innerResultMap.put("TC0588", "PASS");

		} else {
			innerResultMap.put("TC0588", "FAIL");
		}
	  	
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
	    driver.findElement(By.id("account_number")).clear();
	    driver.findElement(By.id("account_number")).sendKeys("1234567894145784");
	    driver.findElement(By.id("btn-submit")).click();
	    assertEquals("", driver.findElement(By.id("account_number_err")).getText());
	    driver.findElement(By.id("btn-submit")).click();
	    
    	if(driver.findElement(By.id("account_number_err")).getText().equals("")){
			innerResultMap.put("TC0589", "PASS");

		} else {
			innerResultMap.put("TC0589", "FAIL");
		}
	  
	    driver.findElement(By.id("btn-submit")).click();
	    try{
	    assertEquals("Please Select an Account Type.", driver.findElement(By.id("account_type_err")).getText());
	    assertEquals("Please Select Account Type Saving Account Current Account", driver.findElement(By.id("account_type")).getText());
    	if(driver.findElement(By.id("account_type")).getText().equals("Please Select Account Type Saving Account Current Account")){
			innerResultMap.put("TC0590", "PASS");

		} else {
			innerResultMap.put("TC0590", "FAIL");
		}
	  	
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
	    new Select(driver.findElement(By.id("account_type"))).selectByVisibleText("Saving Account");
    	if(driver.findElement(By.id("account_type")).isEnabled()){
			innerResultMap.put("TC0591", "PASS");

		} else {
			innerResultMap.put("TC0591", "FAIL");
		}
	    driver.findElement(By.id("btn-submit")).click();
	    try{
	    assertEquals("", driver.findElement(By.id("account_type_err")).getText());
    	if(driver.findElement(By.id("account_type_err")).getText().equals("")){
			innerResultMap.put("TC0592", "PASS");

		} else {
			innerResultMap.put("TC0592", "FAIL");
		}
	  	
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
	    driver.findElement(By.id("btn-submit")).click();
	    try{
	    assertEquals("The IFSC field is required.", driver.findElement(By.id("ifsc_err")).getText());
    	if(driver.findElement(By.id("ifsc_err")).getText().equals("The IFSC field is required.")){
			innerResultMap.put("TC0593", "PASS");

		} else {
			innerResultMap.put("TC0593", "FAIL");
		}
	    driver.findElement(By.id("ifsc")).clear();
	    driver.findElement(By.id("ifsc")).sendKeys("12345678945454545454");
	    driver.findElement(By.id("btn-submit")).click();
	    //assertEquals("Adda52.com", driver.getTitle());
	    try{
	    assertEquals("The IFSC field can not exceed 11 characters in length.", driver.findElement(By.id("ifsc_err")).getText());
    	if(driver.findElement(By.id("ifsc_err")).getText().equals("The IFSC field can not exceed 11 characters in length.")){
			innerResultMap.put("TC0594", "PASS");

		} else {
			innerResultMap.put("TC0594", "FAIL");
		}
	  	
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
	    driver.findElement(By.id("ifsc")).clear();
	    driver.findElement(By.id("ifsc")).sendKeys("12345678941");
	    driver.findElement(By.id("btn-submit")).click();
	  //  assertEquals("Adda52.com", driver.getTitle());
	    try {
	      assertEquals("Home � My-account � Redeem-chips � Successful-redeem", driver.findElement(By.cssSelector("div.breadcrumb")).getText());
	    	if(driver.findElement(By.cssSelector("div.breadcrumb")).getText().equals("Home � My-account � Redeem-chips � Successful-redeem")){
				innerResultMap.put("TC0594", "PASS");

			} else {
				innerResultMap.put("TC0594", "FAIL");
			}
		  	
	    } catch (Error e) {
		      verificationErrors.append(e.toString());
		    }
			common.getInnerResultMap().putAll(innerResultMap);
	    }
			finally {
				acceptNextAlert = true;
			}
	    
	 }


@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}

}
