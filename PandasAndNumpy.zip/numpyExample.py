a= ['$22.0022','$33.3333']

for d in a:
    print d.replace('$','')
    
import numpy as np

a = np.array([1,2,3]) 
print a

a = np.array([[1, 2], [3, 4]]) 
print a


a = np.array([1, 2, 3,4,5], ndmin = 2) 
print a


a = np.array([1, 2, 3], dtype = complex) 
print a

dt = np.dtype(np.int32) 
print dt

dt = np.dtype('i4')
print dt

dt = np.dtype([('age',np.int8)]) 
print dt



dt = np.dtype([('age',np.int8)]) 
a = np.array([(10,),(20,),(30,)], dtype = dt) 
print a





dt = np.dtype([('age',np.int8)]) 
a = np.array([(10,),(20,),(30,)], dtype = dt) 
print a['age']






student = np.dtype([('name','S20'), ('age', 'i1'), ('marks', 'f4')]) 
print student





student = np.dtype([('name','S20'), ('age', 'i1'), ('marks', 'f4')]) 
a = np.array([('abc', 21, 50),('xyz', 18, 75)], dtype = student) 
print a



a = np.array([[1,2,3],[4,5,6]]) 
print a.shape



a = np.array([[1,2,3],[4,5,6]]) 
a.shape = (3,2) 
print a



a = np.array([[1,2,3],[4,5,6]]) 
b = a.reshape(3,2) 
print b

a = np.arange(24) 
a.ndim
print a


# now reshape it 
b = a.reshape(2,4,3) 
print b 
# b is having three dimensions


x = np.array([1,2,3,4,5], dtype = np.int8) 
print x.itemsize


x = np.array([1,2,3,4,5], dtype = np.float32) 
print x.itemsize



