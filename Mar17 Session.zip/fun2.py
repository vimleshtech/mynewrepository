#a. no argument no return
def wel():
    print('This program contains following functions \n\n i. wel \n ii. getcount \n iii. add \n iv. sub   ')
    

#b. no argument with return
def getCount():
    c =111
    return c
    #print(c)
    
#c. argument with no return
def add(c,v):
    d = c+v
    print('sum of two numbers :',d)
    
#d. arugment with return
def mul(d,a):
    o =d *a
    return o



wel()
a = getCount()
a = a+2

print(a)
add(111,2)


add(mul(2,3),10)





