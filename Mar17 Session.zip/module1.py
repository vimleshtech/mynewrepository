def add(a,b):
    c = a+b
    print(c)

def sub(a,b):
    c = a-b
    print(c)

def mul(a,b):
    c = a*b
    print(c)
    
    
