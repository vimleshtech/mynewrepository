# list : is array or collection of data or values   :    [] 
# - multiple values can be stored on single variable

a = ['aa',33222,33333,'3333444']

print(a)
print(a[2])

for d in a:
    print(d)
    

# tuple: is collection of data or values but this values are readonly  :  () 
days = ('mon','tue','wed','thu','fri')

print(days)

print(days[1])
for e in days:
    print(e)

#now allowed 
#days[1] = 'sat'

# dict: is known as dictionary which store data on key pair : {}
words = {'a':'alpha','b':'beta','c':'cat'}

#print(words['b'])
s = input('enter key to be searched :' )
print(words[s])




