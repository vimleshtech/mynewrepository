def add(a,b):    
    c = a+b
    print(c)

def welcome():
    print('welcome to function world...')
    



add(111,22)
add(11,22)
add(1,22)
welcome()



    
