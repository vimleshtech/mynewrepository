#import all functions 
'''
import module1

module1.add(1,22)
module1.mul(2,22)

'''


#import required functions
'''
from module1 import mul,sub

mul(11,2)
sub(2,3)
'''

import module1 as c

c.add(1,2)
c.sub(32,1)







       
