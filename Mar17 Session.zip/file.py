d = open(r'C:\Users\hp\Desktop\Angular Session-1.txt','r')

#print(d.read())
#print(d.readline())

#print(d.readlines())

rc = 0
for e in d.readlines():


    if rc>10:
        break
    
    print(e)


    rc =rc+1
    
